"""Every API call picks its own key, and a failed call rotates instead of failing.

This is the binding the plugin was missing. Everything before it acted *after*
a refusal — size the cooldown, bench the key, hand the pool a better reset time.
None of that chooses the key a request carries, and none of it survives Hermes'
own retry ceiling.

Where this attaches
-------------------

``run_agent.py`` routes every model call through two forwarders::

    def _interruptible_streaming_api_call(self, api_kwargs, *, on_first_delta=None):
        from agent.chat_completion_helpers import interruptible_streaming_api_call
        return interruptible_streaming_api_call(self, api_kwargs, on_first_delta=on_first_delta)

    def _interruptible_api_call(self, api_kwargs):
        from agent.chat_completion_helpers import interruptible_api_call
        return interruptible_api_call(self, api_kwargs)

Both import the module function **inside the method body**, so replacing the
module attribute reaches every caller in the process — the main loop, the
auxiliary lane, compression, subagents, the gateway and the CLI alike — without
touching a class, a subclass, or an instance. It is the same property that
makes ``resolve_runtime_provider`` wrappable, and it is why this plugin can own
the dispatch point without patching Hermes.

What it does per call
---------------------

1. Collect the keys this agent could use — the credential pool's entries when
   there is one, otherwise a comma-split of ``agent.api_key``.
2. Ask :mod:`core.carousel` which one is healthiest *right now*: fewest requests
   in the last 60 seconds, least recently used to break the tie.
3. Put that key on the agent (cheaply — see ``_apply_key``) and call the host's
   own function. KAME does not re-implement the request, exactly as Agent Zero
   v1.0.9 stopped doing: the streaming, the interrupts, the middleware, the
   response shape all stay Hermes'.
4. On success, clear the key's health and return the host's own result.
5. On failure, classify it, rest the key for as long as the evidence justifies,
   and **take the next key** — without the error ever reaching the conversation
   loop, which is what stops it reaching the chat.

Why the loop lives here and not in the host
-------------------------------------------

Hermes retries ``agent._api_max_retries`` times (default **3**) and rotates the
credential pool only for ``billing``, ``rate_limit`` and ``auth``
(``agent_runtime_helpers.recover_with_credential_pool``). A 503 is none of
those, so the observed failure — three 503s and a dead turn, with fourteen
untouched keys in the pool — is the host behaving exactly as designed. Raising
the retry ceiling alone would not fix it either, because the retries would all
go to the same key.

So the carousel runs *inside* one host retry. From the conversation loop's
point of view a call either succeeds or fails once; the fifteen keys it tried
in between are this module's business.

The one limit on that promise, and it is deliberate
---------------------------------------------------

**A partial stream is never replayed.** If the provider delivered tokens and
then dropped, the user has already seen text. Retrying here would print the
answer twice. That failure is re-raised to the host, which has machinery for
exactly it (the ``[System: The previous response was cut off…]`` continuation).
``_progress`` is how the wrapper knows: the delta callbacks are shimmed for the
duration of the attempt, so "nothing arrived yet" is observed rather than
assumed. This mirrors the ``progress["any"]`` flag Agent Zero's v1.0.9 carousel
introduced for the same reason.

**A terminal error is still terminal**, which is a refusal to rotate rather
than a limit on rotating. A malformed request, a 404 model, a
content-policy refusal: no key answers those, and rotating through fifteen of
them would turn one clear error into fifteen slow ones. ``core.carousel.is_terminal``
draws the line, and it checks *auth before status* — Google reports an invalid
key as ``400 INVALID_ARGUMENT: API key not valid``, which every status-first
classifier reads as a permanent client error and aborts the run on. Here it
quarantines that one key and rotates, which is the difference between a dead
session and a turn that finishes on the other fourteen.

Waiting, since 1.0.1
--------------------

There is no ceiling on how long one call may spend rotating. Agent Zero's
ADR 0002 reached the same conclusion for the same reason — every artificial
timeout it tried became the cause of the failure it was meant to prevent — but
recorded one risk it could not close: a socket that hangs without ever erroring
would be waited on forever. Hermes closes it. Each attempt already carries the
host's own per-request timeout (``run_agent.py:1394``, 1800 s by default), so a
hung connection surfaces as a ``TimeoutError`` the carousel rotates on. And the
agent runs in a worker thread, so a long sleep here blocks neither the event
loop, nor the websocket, nor the stop button.

What Agent Zero does not have is the other half: ADR 0002 admits that when
every key is spent *"the user typically restarts A0"*. A restart is not a
decision the user made; it is one the silence made for them. So the wait is
unbounded **and** narrated — see :class:`_Vigil`.

Switching it off
----------------

``KAME_CAROUSEL_DISABLED=1`` (or ``carousel_disabled`` in the plugin's config
entry) removes the wrapper's effect entirely and leaves Hermes' own retry and
rotation in charge.
"""

from __future__ import annotations

import functools
import logging
import sys
import time
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple

from . import settings
from .core import multikey
from .core.storm import StormFilter, Verdict
from .core.carousel import (
    EMPTY_REST_S,
    EMPTY_RETRY_BUDGET,
    ENGINE,
    Carousel,
    classify,
    fingerprint,
    format_duration,
    is_auth_failure,
    is_terminal,
)

logger = logging.getLogger(__name__)

_MARK = "__kame_carousel__"

#: What the storm filter would have said if it were switched off: print
#: everything, hold nothing back. A constant rather than a branch around the
#: logging block, so the switched-off path runs the same code as the other one
#: and cannot drift away from it.
_ALWAYS_LOUD = Verdict(speak_full=True)

_MODULE = "agent.chat_completion_helpers"

#: Both dispatch functions, wrapped identically. The streaming one carries an
#: ``on_first_delta`` keyword; the wrapper forwards ``**kwargs`` untouched so a
#: future Hermes adding a parameter cannot break it.
_FUNCTIONS = ("interruptible_streaming_api_call", "interruptible_api_call")

#: Raised to mean "the user pressed the button", not "the provider failed".
#: Retrying these would ignore an interrupt, so they pass straight through.
_CONTROL_FLOW = (KeyboardInterrupt, SystemExit, GeneratorExit, InterruptedError)

#: Longest single sleep while the whole pool is resting. Slept in one-second
#: slices so an interrupt is honoured within a second, and re-checked after so
#: a key that recovers early is used immediately.
_SLEEP_SLICE_S = 1.0
_MAX_SLEEP_S = 60.0

#: A wait shorter than this is a hiccup and saying so would be noise. Longer
#: than this and silence becomes indistinguishable from a hang, which is the
#: real complaint behind "is it frozen?" — so the first notice goes out here.
VIGIL_FIRST_S = 5.0

#: And then at this interval, so an hour-long wait produces a handful of lines
#: rather than sixty. Each one carries the current estimate, which moves as
#: keys recover, so a repeat is information rather than a reminder.
VIGIL_REPEAT_S = 600.0


class Incompatible(Exception):
    """The installed Hermes does not present the surface this module needs."""


# --- reading the agent ------------------------------------------------------


def _entries_of(agent: Any) -> List[Any]:
    """The credential pool's entries, or an empty list.

    Entries are preferred over raw strings because they carry a base URL and an
    id, which is what ``_apply_key`` needs to swap a key correctly on the
    Anthropic path. Everything is guarded: this runs on the hot path of every
    API call, and no read of an arbitrary host object is allowed to cost a turn.
    """
    pool = getattr(agent, "_credential_pool", None)
    if pool is None:
        return []
    try:
        entries = list(pool.entries())
    except Exception:
        return []
    usable = []
    for entry in entries:
        try:
            key = getattr(entry, "runtime_api_key", None) or getattr(entry, "access_token", "")
        except Exception:
            continue
        if str(key or "").strip():
            usable.append(entry)
    return usable


def _key_of(entry: Any) -> str:
    try:
        value = getattr(entry, "runtime_api_key", None) or getattr(entry, "access_token", "")
    except Exception:
        return ""
    return str(value or "").strip()


def candidates(agent: Any) -> Tuple[List[str], Dict[str, Any]]:
    """``(keys, entry_by_key)`` — everything this agent is allowed to send.

    Three sources, in order of authority:

    * the credential pool, which is where a Hermes that was configured through
      the UI keeps them;
    * a comma-separated ``agent.api_key``, which is where a Hermes configured
      through an environment variable keeps them, and which the resolver
      binding has already reduced to one key for the *first* call of a session
      but not for the rest;
    * the single resolved key, which is not a pool at all — the carousel still
      earns its keep there, because backoff and eternal retry apply to one key
      just as they do to fifteen.
    """
    entry_by_key: Dict[str, Any] = {}
    keys: List[str] = []
    for entry in _entries_of(agent):
        key = _key_of(entry)
        if key and key not in entry_by_key:
            entry_by_key[key] = entry
            keys.append(key)

    current = str(getattr(agent, "api_key", "") or "").strip()
    if not keys:
        split, _rejected = multikey.split_value(current)
        keys = split if len(split) > 1 else ([current] if current else [])
    elif current and current not in entry_by_key:
        # The agent is carrying a key the pool does not know — a resolver
        # substitution, a fallback provider, a manually set key. It is a
        # working credential and dropping it would narrow what the host would
        # have sent, which this plugin never does.
        keys.append(current)
    return keys, entry_by_key


def _apply_key(agent: Any, key: str, entry: Any) -> bool:
    """Put ``key`` on the agent for the next request. ``True`` if it took.

    The cheap path is the one Hermes itself uses when it rewrites a key
    mid-loop (``conversation_loop.py``, the non-ASCII sanitiser): assign
    ``api_key``, keep ``_client_kwargs`` in step, and update the live client,
    which reads its own copy when it builds auth headers on every request. No
    client is rebuilt, because every key in a pool shares the provider's base
    URL — rebuilding one client per call would cost more than the rotation
    saves.

    The Anthropic path cannot do that: ``build_anthropic_client`` bakes the key
    into the client at construction. There, and only there, the host's own
    ``_swap_credential`` is used, and only when a pool entry is available to
    hand it. Rotating on that path costs a client rebuild; not rotating would
    be a silent lie about what the plugin does.
    """
    if not key:
        return False
    if str(getattr(agent, "api_key", "") or "") == key:
        # Already carrying it — nothing to write, but the attribution still
        # has to be right. If this call does fail into the host, Hermes reads
        # ``_credential_pool_entry_id`` to decide which entry to bench, and a
        # stale id from a previous rotation would bench a healthy key.
        _attribute(agent, entry)
        return True

    if getattr(agent, "api_mode", "") == "anthropic_messages":
        swap = getattr(agent, "_swap_credential", None)
        if entry is None or not callable(swap):
            return False
        try:
            swap(entry)
            return True
        except Exception:
            logger.debug("kame: could not swap the Anthropic credential", exc_info=True)
            return False

    try:
        agent.api_key = key
        client_kwargs = getattr(agent, "_client_kwargs", None)
        if isinstance(client_kwargs, dict):
            client_kwargs["api_key"] = key
        client = getattr(agent, "client", None)
        if client is not None and hasattr(client, "api_key"):
            client.api_key = key
        _attribute(agent, entry)
        return True
    except Exception:
        logger.debug("kame: could not place the selected key on the agent", exc_info=True)
        return False


def _attribute(agent: Any, entry: Any) -> None:
    """Tell the host which pool entry sent this request.

    Hermes reads ``_credential_pool_entry_id`` when it benches a credential
    (``agent_runtime_helpers.recover_with_credential_pool``). Leaving it
    pointing at the previous rotation's entry would bench a healthy key for a
    failure it never had — the exact mis-attribution the host's own code goes
    out of its way to avoid.
    """
    if entry is None:
        return
    try:
        entry_id = getattr(entry, "id", None)
        if isinstance(entry_id, str) and entry_id:
            agent._credential_pool_entry_id = entry_id
    except Exception:  # pragma: no cover — a plain attribute write
        pass


# --- watching the stream ----------------------------------------------------


class _Progress:
    """Flipped the instant anything reaches the user.

    The wrapper cannot count tokens — it does not own the stream any more than
    Agent Zero's v1.0.9 carousel does. It watches the callbacks instead, and
    every shim returns whatever the real callback returned, because Hermes uses
    those return values to control early stopping.
    """

    __slots__ = ("any",)

    def __init__(self) -> None:
        self.any = False


def _shim(progress: _Progress, callback: Any) -> Any:
    if not callable(callback):
        return callback

    @functools.wraps(callback)
    def _watched(*args, **kwargs):
        progress.any = True
        return callback(*args, **kwargs)

    return _watched


def _install_shims(agent: Any, progress: _Progress, kwargs: Dict[str, Any]) -> Dict[str, Any]:
    """Wrap every delivery callback for one attempt; returns what to restore."""
    restore: Dict[str, Any] = {}
    for name in ("stream_delta_callback", "_stream_callback", "thinking_callback"):
        original = getattr(agent, name, None)
        if callable(original):
            restore[name] = original
            try:
                setattr(agent, name, _shim(progress, original))
            except Exception:
                restore.pop(name, None)
    if callable(kwargs.get("on_first_delta")):
        kwargs["on_first_delta"] = _shim(progress, kwargs["on_first_delta"])
    return restore


def _remove_shims(agent: Any, restore: Dict[str, Any]) -> None:
    for name, original in restore.items():
        try:
            setattr(agent, name, original)
        except Exception:  # pragma: no cover — the setattr that worked once
            pass


class _Vigil:
    """Tells the user a long wait is a wait, not a freeze.

    Agent Zero's carousel waits without a ceiling and without a word; ADR 0002
    records the consequence honestly — *"the user typically restarts A0 in that
    scenario"*. Restarting is not a decision the user made, it is one the
    silence made for them. A pool that hits its daily cap at 14:00 does not
    recover until midnight Pacific, and ten hours of a spinner is
    indistinguishable from a hang no matter how correct the waiting is.

    So the wait stays unbounded and stops being silent. ``agent._emit_status``
    is the host's own lifecycle channel (``run_agent.py:964``): CLI users see
    it printed with ``force=True``, gateway users receive it through
    ``status_callback("lifecycle", ...)``, and it is documented never to raise
    — "exceptions are swallowed so it cannot interrupt the retry/fallback
    logic". Exactly the guarantee a notice from inside the carousel needs.
    """

    __slots__ = ("agent", "label", "started", "_next", "notices")

    def __init__(self, agent: Any, label: str) -> None:
        self.agent = agent
        self.label = label
        self.started = time.monotonic()
        self._next = VIGIL_FIRST_S
        self.notices = 0

    @property
    def waited(self) -> float:
        return time.monotonic() - self.started

    def maybe_speak(self, healthy: int, total: int, eta: Optional[float]) -> None:
        """Emit a notice if this wait has now been going on long enough."""
        waited = self.waited
        if waited < self._next:
            return
        self._next = waited + VIGIL_REPEAT_S
        self.notices += 1
        if eta is None:
            when = "waiting for the next opening"
        else:
            when = f"next key in {format_duration(eta)}"
        resting = max(total - healthy, 0)
        # Surface the notice through the host's live status/thinking channel
        # so Desktop, TUI and CLI show the wait notice immediately in the UI spinner.
        notice_fn = getattr(self.agent, "_emit_wait_notice", None)
        if callable(notice_fn):
            try:
                notice_fn(f"⏳ KAME: {resting}/{total} chaves descansando ({when})")
            except Exception:
                pass

        self._emit(
            f"KAME: {self.label} — {resting} of {total} key(s) resting, {when}. "
            f"Waiting {format_duration(waited)} so far; no requests are being "
            f"sent. Press stop to cancel."
        )

    def done(self) -> None:
        """Close the loop, but only if the user was told it was open."""
        if not self.notices:
            return
        self._emit(
            f"KAME: {self.label} — back up after {format_duration(self.waited)}."
        )

    def _emit(self, message: str) -> None:
        emit = getattr(self.agent, "_emit_status", None)
        if not callable(emit):
            logger.info("kame: %s", message)
            return
        try:
            emit(message)
        except Exception:
            # Documented not to raise; if a host ever changes that, a notice
            # must not be the thing that ends a turn that was recovering.
            logger.debug("kame: could not emit a waiting notice", exc_info=True)


def _interrupted(agent: Any) -> bool:
    try:
        return bool(getattr(agent, "_interrupt_requested", False))
    except Exception:
        return False


def _result_is_empty(result: Any) -> bool:
    """Whether the host's answer carried no content at all.

    A squeezed free-tier key returns 200 and nothing rather than refusing. The
    first such answer from a key is treated as a provider hiccup and costs the
    key nothing; the rule for the second one lives in the carousel loop.
    """
    if result is None:
        return True
    try:
        choices = getattr(result, "choices", None)
        if choices:
            message = getattr(choices[0], "message", None)
            content = getattr(message, "content", None) if message is not None else None
            tool_calls = getattr(message, "tool_calls", None) if message is not None else None
            if tool_calls:
                return False
            return not str(content or "").strip()
        content = getattr(result, "content", None)
        if isinstance(content, str):
            return not content.strip()
        if isinstance(content, list):
            return not any(
                str(getattr(part, "text", "") or "").strip() for part in content
            )
    except Exception:
        return False
    return False


# --- the binding ------------------------------------------------------------


class DispatchBinding:
    """Installs, owns, and can fully remove the per-call carousel."""

    def __init__(
        self,
        *,
        engine: Optional[Carousel] = None,
        sleep: Optional[Callable[[float], None]] = None,
    ) -> None:
        # ``sleep`` is injectable for one reason: since 1.0.1 a wait can last
        # hours, and a test that proves an hour-long wait behaves must not take
        # an hour. Nothing in the shipped path passes it.
        self._sleep = sleep or time.sleep
        self._module: Any = None
        self._originals: Dict[str, Callable] = {}
        self.installed = False
        self.reason = "not installed"
        self.engine = engine or ENGINE
        # For ``/kame-quota``: an install that has never rotated and one that
        # is silently inert are otherwise indistinguishable.
        self.calls = 0
        self.rotations = 0
        self.recovered = 0
        self.surfaced = 0
        # Since 1.0.1 the carousel can wait for hours, so how much of a turn
        # was spent waiting is the number that explains a slow session.
        self.waited_s = 0.0
        self.waits = 0
        # Since 1.0.2. It lives on the binding rather than on a call because an
        # outage does not end when a turn does: the provider is still down on
        # the next message, and a filter that reset per call would print its
        # loud opening lines again every turn and never reach the collapse.
        self._storm = StormFilter()
        self.suppressed = 0

    # -- lifecycle -------------------------------------------------------

    def install(self, module: Any) -> bool:
        """Wrap both dispatch functions. Never raises; a refusal is an outcome."""
        if self.installed:
            return True
        if module is None:
            self.reason = f"{_MODULE} is not importable in this process"
            logger.info("kame: every call keeps the host's key — %s", self.reason)
            return False

        originals: Dict[str, Callable] = {}
        for name in _FUNCTIONS:
            function = getattr(module, name, None)
            if not callable(function):
                self.reason = f"{_MODULE} has no {name}()"
                logger.info("kame: every call keeps the host's key — %s", self.reason)
                return False
            if getattr(function, _MARK, False):
                self.reason = "already wrapped by another KAME instance"
                logger.debug("kame: %s", self.reason)
                return False
            originals[name] = function

        self._module = module
        self._originals = originals
        for name, original in originals.items():
            setattr(module, name, self._wrap(original))
        self.installed = True
        self.reason = "active"
        logger.info(
            "kame: every API call picks the healthiest key and rotates on "
            "failure, waiting as long as a key needs"
        )
        return True

    def uninstall(self) -> None:
        if not self.installed or self._module is None:
            return
        for name, original in self._originals.items():
            if getattr(getattr(self._module, name, None), _MARK, False):
                setattr(self._module, name, original)
        self._module = None
        self._originals = {}
        self.installed = False
        self.reason = "uninstalled"

    # -- the wrapper -----------------------------------------------------

    def _wrap(self, original: Callable) -> Callable:
        binding = self

        @functools.wraps(original)
        def _kame_dispatch(agent, api_kwargs, *args, **kwargs):
            if settings.is_on(settings.ROTATION_DISABLED) or settings.is_on(
                settings.CAROUSEL_DISABLED
            ):
                return original(agent, api_kwargs, *args, **kwargs)
            try:
                return binding.run(original, agent, api_kwargs, args, kwargs)
            except _CONTROL_FLOW:
                raise
            except Exception:
                raise

        setattr(_kame_dispatch, _MARK, True)
        return _kame_dispatch

    # -- the carousel ----------------------------------------------------

    def run(
        self,
        original: Callable,
        agent: Any,
        api_kwargs: Any,
        args: Sequence[Any],
        kwargs: Dict[str, Any],
    ) -> Any:
        """One API call, as many keys as it takes."""
        try:
            keys, entry_by_key = candidates(agent)
        except Exception:
            logger.debug("kame: could not read the agent's keys", exc_info=True)
            return original(agent, api_kwargs, *args, **kwargs)

        if not keys:
            # Nothing to choose from — an OAuth provider, a callable bearer, a
            # local model. The host's own call is the whole behaviour.
            return original(agent, api_kwargs, *args, **kwargs)

        identity = Carousel.identity(
            getattr(agent, "provider", ""), getattr(agent, "model", "")
        )
        label = identity
        started = time.monotonic()
        self.calls += 1

        attempt = 0
        slept = False
        vigil: Optional[_Vigil] = None
        empty_budget = EMPTY_RETRY_BUDGET
        empty_counts: Dict[str, int] = {}
        last_error: Optional[BaseException] = None

        while True:
            attempt += 1
            if _interrupted(agent):
                if last_error is not None:
                    raise last_error
                return original(agent, api_kwargs, *args, **kwargs)

            key, status = self.engine.select(identity, keys)
            if key is None:
                return original(agent, api_kwargs, *args, **kwargs)

            if status == "EXHAUSTED":
                # Every key is resting. Calling one anyway would spend a
                # request we already know will be refused and would deepen the
                # cooldown that caused this. Wait for the soonest instead —
                # for as long as it takes, since 1.0.1, but never in silence.
                if vigil is None:
                    vigil = _Vigil(agent, label)
                if not self._wait_for_recovery(agent, identity, keys, vigil):
                    # Only an interrupt, or a pool with no recovery to wait
                    # for, ends the wait now.
                    if last_error is not None:
                        self.surfaced += 1
                        raise last_error
                    # Nothing failed yet and the pool is cold from an earlier
                    # turn: let the host make the call and report honestly.
                    return original(agent, api_kwargs, *args, **kwargs)
                slept = True
                continue

            _apply_key(agent, key, entry_by_key.get(key))

            # Live UI Feedback: tell the desktop/TUI spinner what KAME is doing in real-time
            _notify_ui = getattr(agent, "_emit_wait_notice", None)
            if callable(_notify_ui):
                try:
                    fp = fingerprint(key)
                    if attempt > 1:
                        _notify_ui(f"🔄 KAME: Rotacionando -> chave {fp} (Tentativa {attempt})...")
                    else:
                        _notify_ui(f"⚡ KAME: Despachando via chave {fp}...")
                except Exception:
                    pass

            progress = _Progress()
            call_kwargs = dict(kwargs)
            restore = _install_shims(agent, progress, call_kwargs)
            try:
                result = original(agent, api_kwargs, *args, **call_kwargs)
            except _CONTROL_FLOW:
                raise
            except BaseException as exc:  # noqa: BLE001 — re-raised below unless rotatable
                last_error = exc
                verdict = self._on_failure(
                    identity, key, exc, label, attempt, progress.any
                )
                if verdict == "raise":
                    self.surfaced += 1
                    raise
                self.rotations += 1
                continue
            finally:
                _remove_shims(agent, restore)

            # An answer that carried nothing. Usually a provider hiccup or a
            # filtered completion, so the first one from a key costs it
            # nothing. A second from the same key rests it briefly. Bounded by
            # the budget, after which the empty answer is returned exactly as
            # the host would have returned it — this can never become a loop.
            if empty_budget > 0 and not progress.any and _result_is_empty(result):
                empty_budget -= 1
                empty_counts[key] = empty_counts.get(key, 0) + 1
                if empty_counts[key] >= 2:
                    self.engine.mark(identity, key, False, EMPTY_REST_S, "other")
                logger.info(
                    "kame: %s %s answered with nothing (%d) — next key",
                    label,
                    fingerprint(key),
                    empty_counts[key],
                )
                self.rotations += 1
                continue

            self.engine.mark(identity, key, True)
            if vigil is not None:
                vigil.done()
            # A key answered, so whatever was repeating has stopped. The recap
            # is the line that makes the collapse safe to read: without it a
            # reader knows a storm started and never learns how big it got.
            recap = self._storm.ended(time.monotonic())
            if recap:
                logger.warning("kame: %s %s", label, recap)
            if slept:
                thawed = self.engine.thaw_server_cooled(identity, key)
                if thawed:
                    logger.info(
                        "kame: %s recovered — %d key(s) brought back early", label, thawed
                    )
            if attempt > 1:
                self.recovered += 1
                logger.info(
                    "kame: %s answered on attempt %d with %s after %s",
                    label,
                    attempt,
                    fingerprint(key),
                    format_duration(time.monotonic() - started),
                )
            return result

    # -- the two decisions -----------------------------------------------

    def _on_failure(
        self,
        identity: str,
        key: str,
        exc: BaseException,
        label: str,
        attempt: int,
        streamed: bool,
    ) -> str:
        """``"rotate"`` or ``"raise"``, and the key's rest recorded either way.

        A failure is always *learned from*, even when it is re-raised — a
        terminal error still tells us nothing bad about the key, and a
        mid-stream drop still does.
        """
        message = str(getattr(exc, "message", "") or "")
        if is_terminal(exc, message):
            logger.info(
                "kame: %s %s — the request itself was refused, not the key", label, type(exc).__name__
            )
            return "raise"

        delay, kind, status = classify(
            exc, message, daily_cooldown_s=self.engine.daily_cooldown_s
        )
        applied = self.engine.mark(identity, key, False, delay, kind, )
        # Never the error text: a provider's unredacted dump of a failed auth
        # call can carry the key that failed.
        #
        # Since 1.0.2 this goes past the storm filter first. During an outage
        # the same sentence repeats with nothing new in it, and 1.0.1 made that
        # worse rather than better: with the ceiling gone the carousel keeps
        # rotating for as long as the provider keeps refusing, so what used to
        # be ten minutes of repetition is now however long the outage lasts.
        # The filter is bypassed entirely when switched off, and it can only
        # ever decide what gets *written* — the rest, and the key, are already
        # decided above.
        if settings.is_on(settings.STORM_COLLAPSE_DISABLED):
            verdict = _ALWAYS_LOUD
        else:
            verdict = self._storm.observe(
                kind, status, fingerprint(key), time.monotonic()
            )
        if verdict.summary:
            logger.warning("kame: %s %s", label, verdict.summary)
        if verdict.speak_full:
            logger.warning(
                "kame: %s %s %s%s — resting %s, taking the next key (attempt %d)",
                label,
                fingerprint(key),
                kind,
                f" [{status}]" if status else "",
                format_duration(applied),
                attempt,
            )
        else:
            self.suppressed += 1
        if is_auth_failure(exc, message):
            # Actionable and permanent: this one is worth saying loudly, once
            # per occurrence, because no amount of rotation repairs it.
            logger.error(
                "kame: %s %s is not a valid credential — quarantined for %s. "
                "Replace it in Settings; the remaining keys are carrying this turn.",
                label,
                fingerprint(key),
                format_duration(applied),
            )
        if streamed:
            # The user has already seen part of an answer. Replaying it would
            # print the response twice, so this one goes back to Hermes, which
            # knows how to continue a cut-off response.
            logger.info(
                "kame: %s dropped mid-answer — handing it to Hermes rather than "
                "printing the reply twice",
                label,
            )
            return "raise"
        return "rotate"

    def _wait_for_recovery(
        self, agent: Any, identity: str, keys: Sequence[str], vigil: "_Vigil"
    ) -> bool:
        """Sleep until the soonest key is usable. ``False`` means stop waiting.

        Since 1.0.1 there is no ceiling on the total wait, matching Agent Zero's
        ADR 0002. Two host facts make that safe here in a way it never was
        there: every attempt already carries Hermes' own per-request timeout
        (1800 s by default, ``run_agent.py:1394``), so a genuinely hung socket
        surfaces as a ``TimeoutError`` this carousel rotates on rather than
        hanging forever; and the agent runs in a worker thread
        (``asyncio.to_thread``), so sleeping here never blocks the event loop,
        the websocket, or the stop button.

        Only two things end the wait: an interrupt, or a pool with nothing to
        wait for. Slept in one-second slices so a stop is honoured within a
        second, and capped per pass so a long cooldown is re-checked rather
        than committed to — a key that recovers early, or a pool that gains a
        key, is used immediately.
        """
        eta = self.engine.next_recovery_seconds(identity, keys)
        healthy = self.engine.healthy_count(identity, keys)
        vigil.maybe_speak(healthy, len(keys), eta)
        if eta is None:
            # The selector said every key was resting and the clock says one is
            # ready — a key recovered in the microseconds between the two
            # reads, or another thread just freed one. Re-select immediately,
            # but never without yielding first: with no ceiling above this loop
            # any disagreement between the two answers would otherwise spin a
            # core until the process died. One slice is enough to make it a
            # re-check instead of a spin, and it keeps the stop button honest.
            wait = _SLEEP_SLICE_S
        else:
            wait = min(eta + 0.5, _MAX_SLEEP_S)
        if wait <= 0:
            wait = _SLEEP_SLICE_S
        # Debug since 1.0.2, and it was a warning before. This fires once per
        # pass through the wait, which under 1.0.1's unbounded wait means once
        # a minute for as long as the quota lasts — the same storm the failure
        # lines had, in the one place where nothing is actually happening.
        # ``_Vigil`` above already narrates the wait, on a schedule built for a
        # person to read (90 s, then every 10 minutes) and through the user's
        # own channel, falling back to this logger when the host has none. So
        # the information is not lost, only paced.
        logger.debug(
            "kame: %s every key is resting — waiting %s (no requests sent); "
            "earliest recovery %s",
            vigil.label,
            format_duration(wait),
            "now" if eta is None else f"in {format_duration(eta)}",
        )
        self.waits += 1
        slept = 0.0
        while slept < wait:
            if _interrupted(agent):
                self.waited_s += slept
                return False
            slice_s = min(_SLEEP_SLICE_S, wait - slept)
            self._sleep(slice_s)
            slept += slice_s
        self.waited_s += slept
        return True


def install(module: Optional[Any] = None) -> Optional[DispatchBinding]:
    """Convenience entry point used by ``register()``; never raises.

    Imports the module when it is not already loaded, for the same reason the
    resolver binding does: plugin registration runs early, and a binding that
    installs only when something happened to import the host module first is a
    binding that works on some starts and not others. The module is plain — no
    server, no socket, no I/O at import.
    """
    if settings.is_on(settings.ROTATION_DISABLED) or settings.is_on(
        settings.CAROUSEL_DISABLED
    ):
        return None
    try:
        if module is None:
            module = sys.modules.get(_MODULE)
        if module is None:
            from importlib import import_module

            module = import_module(_MODULE)
        binding = DispatchBinding()
        binding.engine.daily_cooldown_s = settings.number(
            settings.DAILY_COOLDOWN, binding.engine.daily_cooldown_s
        )
        return binding if binding.install(module) else None
    except ImportError:
        logger.debug("kame: no %s to bind", _MODULE)
        return None
    except Exception:
        logger.warning("kame: every call keeps the host's key", exc_info=True)
        return None

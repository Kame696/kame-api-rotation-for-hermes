"""Two host settings KAME turns down, and puts back when it leaves.

Both are read by ``agent.chat_completion_helpers`` out of the environment on
every call, so changing them here reaches the host without patching it. Both
are left strictly alone when the user has set them: an explicit value is an
instruction, and a plugin that silently overrules one is a plugin that cannot
be reasoned about.

``HERMES_STREAM_RETRIES`` (host default 2)
    Hermes retries the SAME key up to twice before the failure reaches KAME.
    Under a carousel that is pure dead latency -- KAME already knows the key is
    spent and has fourteen others waiting -- and on a 429 it is worse than
    latency, because the two extra requests deepen the very cooldown that
    caused the failure. Agent Zero hit this exact wall and measured it: "that
    hang was A0's own retry loop (2 attempts x 1.5s per key, on a key KAME
    already knew was rate-limited)". A0 switches it off per call by passing
    ``a0_retry_attempts=0``; Hermes exposes no per-call equivalent, so KAME
    switches it off for the process it is rotating in, and puts it back on
    uninstall.

    This is not KAME removing a safety net. The net moves: a failure that used
    to be retried on the same key is now retried on the next one, immediately,
    by the mechanism whose entire job that is.

``HERMES_STREAM_READ_TIMEOUT`` (host default 120)
    Only touched when ``silent_stream_patience_seconds`` is set, which it is
    not by default. See the long note on that setting for why the host's own
    read timeout is the right mechanism and a watchdog of KAME's own is not.
"""

from __future__ import annotations

import logging
import os
from typing import Dict, Optional

from . import settings

logger = logging.getLogger(__name__)

RETRIES_VAR = "HERMES_STREAM_RETRIES"
READ_TIMEOUT_VAR = "HERMES_STREAM_READ_TIMEOUT"

#: What was there before KAME wrote anything, so uninstall is exact. A variable
#: KAME did not set is not in here and is never removed.
_restore: Dict[str, Optional[str]] = {}


def _claim(name: str, value: str, why: str) -> bool:
    """Set ``name`` unless the user already has an opinion about it."""
    if name in _restore:
        return False  # already ours
    existing = os.environ.get(name)
    if existing is not None:
        logger.info(
            "kame: leaving %s=%s alone — it was set before KAME loaded, and an "
            "explicit value outranks %s",
            name, existing, why,
        )
        return False
    _restore[name] = existing
    os.environ[name] = value
    return True


def apply() -> None:
    """Turn both down, as far as the settings allow. Never raises."""
    try:
        if not settings.is_on(settings.HOST_RETRY_SUPPRESSION_DISABLED):
            if _claim(RETRIES_VAR, "0", "the carousel"):
                logger.info(
                    "kame: %s=0 — a failed call now takes the next key instead "
                    "of retrying the spent one twice first",
                    RETRIES_VAR,
                )
        patience = settings.number(settings.SILENT_STREAM_PATIENCE, 0.0)
        if patience > 0:
            if _claim(READ_TIMEOUT_VAR, str(int(patience)), "silent-stream patience"):
                logger.info(
                    "kame: %s=%ds — one attempt may deliver nothing for that "
                    "long before the next key is tried",
                    READ_TIMEOUT_VAR, int(patience),
                )
    except Exception:  # pragma: no cover — environment writes do not fail
        logger.debug("kame: could not tune the host environment", exc_info=True)


def undo() -> None:
    """Put back exactly what was there. Never raises."""
    for name, previous in list(_restore.items()):
        try:
            if previous is None:
                os.environ.pop(name, None)
            else:
                os.environ[name] = previous
        except Exception:  # pragma: no cover
            pass
        _restore.pop(name, None)


def described() -> Dict[str, str]:
    """What KAME changed, for ``/kame``. Empty when it changed nothing."""
    return {name: os.environ.get(name, "") for name in _restore}

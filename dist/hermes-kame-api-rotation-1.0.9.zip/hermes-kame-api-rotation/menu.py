"""The ``/kame`` slash command — the settings panel Hermes never draws.

Hermes reads ``config_schema`` out of a plugin manifest and validates it, but
nothing in the shipped web UI renders it back: the Plugins page offers an
on/off toggle and nothing else. So every switch this plugin has was, before
1.0.9, real, documented, and unreachable without hand-editing a YAML file the
user had no reason to know existed. A knob nobody can find is a knob nobody
has.

Three verbs, and the split is deliberate:

``/kame``           what the pool is doing right now
``/kame get``       every setting, its value, and where that value came from
``/kame set k v``   change one, in this process and across restarts

``set`` writes ``KAME_*`` lines into Hermes' own ``.env`` because that is the
file Hermes already reads for durable environment, and because KAME's
precedence puts the environment above config — so a single write is both the
immediate change and the permanent one, with no restart in between. The write
is surgical: every line that is not the variable being set is copied through
byte for byte, and the file is never read into a log or into a return value.
It holds credentials, and this module only ever matches lines that begin with
``KAME_``.

``/kame-keys`` and ``/kame-quota`` stay where they are. This is the panel;
those two are the jobs big enough to have earned their own command, and one
of them writes credentials — keeping it out of here means a settings panel
can never grow a code path that touches a key.
"""

from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from . import settings
from .core import __version__
from .core.carousel import format_duration

logger = logging.getLogger(__name__)

COMMAND_NAME = "kame"
COMMAND_DESCRIPTION = "KAME rotation status and settings (KAME)"
COMMAND_ARGS_HINT = "[get | set <key> <value>]"

#: Host settings worth showing beside KAME's own, because a question about
#: KAME's behaviour is very often really a question about one of these four.
#: Defaults are Hermes' own, read from the source noted in each comment; they
#: are shown only when the variable is unset, and labelled as the host's.
_HOST_VARS = (
    ("HERMES_STREAM_RETRIES", "2", "retries on the SAME key before KAME sees a failure"),
    ("HERMES_STREAM_READ_TIMEOUT", "120", "silence allowed inside one attempt"),
    ("HERMES_STREAM_STALE_TIMEOUT", "180", "before Hermes calls a stream stale"),
    ("HERMES_STREAM_STALE_GIVEUP", "5", "stale streams before Hermes refuses the call itself"),
)

_HELP = """/kame — rotation status and settings

  /kame                  what the pool is doing right now
  /kame get              every setting, its value, and where it came from
  /kame set <key> <v>    change one setting, now and after a restart
  /kame help             this text

`set` writes to the .env file Hermes reads on start, and the environment
outranks the plugin config, so the change is live immediately *and* survives
a restart without anyone editing YAML. Only lines beginning with KAME_ are
ever touched, and the file is never printed back.

Switches take true/false, on/off, or 1/0. Numbers are in seconds.

Related: /kame-keys adds pooled keys in bulk, /kame-quota shows what is
benched per model and what KAME has learned about each deadline."""


def _env_path() -> Optional[Path]:
    """Hermes' own ``.env``, asked of Hermes rather than guessed at.

    Imported inside the function so this module stays importable with no
    Hermes in the process, which is how the test suite exercises it — the
    same rule the other two commands follow.
    """
    try:
        from hermes_cli.config import get_env_path

        path = get_env_path()
        return Path(path) if path else None
    except Exception:
        logger.debug("kame: this Hermes exposes no .env path", exc_info=True)
        return None


def _write_env(name: str, value: str) -> Tuple[bool, str]:
    """Set one ``KAME_*`` line in Hermes' ``.env``. Returns ``(ok, detail)``.

    The whole file is rewritten because there is no line-level API for it,
    which makes "everything else is left exactly as it was" a property worth
    stating rather than assuming: a line is matched only on the exact
    variable name being set, every other line — comments, blanks, and every
    credential in there — is copied through unchanged, and nothing read is
    ever logged or returned.
    """
    if not name.startswith("KAME_"):
        # Belt and braces. The caller only ever passes a name that came out of
        # ``settings.env_name``, but this function edits a file full of
        # secrets, so it refuses anything outside the plugin's own namespace
        # rather than trusting its one caller to stay correct forever.
        return False, f"refusing to write {name}: only KAME_* variables belong to this plugin"
    path = _env_path()
    if path is None:
        return False, "this Hermes exposes no .env path, so the change applies to this session only"
    try:
        lines = path.read_text(encoding="utf-8").splitlines() if path.is_file() else []
    except Exception as exc:
        return False, f"could not read {path}: {type(exc).__name__}"

    replaced = False
    out: List[str] = []
    for line in lines:
        stripped = line.lstrip()
        if stripped.startswith(f"{name}=") and not stripped.startswith("#"):
            if not replaced:
                out.append(f"{name}={value}")
                replaced = True
            # A second assignment of the same variable is dropped rather than
            # kept: dotenv takes the last one, so leaving a stale duplicate
            # below the line we just wrote would silently undo the write.
            continue
        out.append(line)
    if not replaced:
        if out and out[-1].strip():
            out.append("")
        out.append("# KAME API Rotation")
        out.append(f"{name}={value}")

    try:
        path.write_text("\n".join(out) + "\n", encoding="utf-8")
    except Exception as exc:
        return False, f"could not write {path}: {type(exc).__name__}"
    return True, f"{'updated' if replaced else 'added'} in {path}"


class MenuCommand:
    """The panel. Reads live state; writes only KAME's own settings."""

    def __init__(self, binding: Any = None) -> None:
        self._binding = binding

    # -- what is happening now --------------------------------------------

    def _rotation_lines(self) -> List[str]:
        """Counters and pool health, or the reason there are none.

        Read off the live binding rather than off a store, because the
        interesting question here is about *this* process: an install that
        refused and an install that has simply had nothing to do look
        identical from the outside, and only ``reason`` tells them apart.
        """
        binding = self._binding
        if binding is None:
            return [
                "Rotation: NOT INSTALLED — every call carries the key Hermes",
                "resolved, and a failure follows Hermes' own retry rules.",
                "The log line beginning `kame: every call keeps the host's key`",
                "says why.",
            ]

        lines = [f"Rotation: {getattr(binding, 'reason', 'unknown')}"]
        # Every number below is for this Hermes process, not for this chat.
        # One process serves every open conversation, the auxiliary lane and
        # every subagent through one binding, and the counters are the
        # binding's. Saying so is the difference between "KAME rotated twice
        # for me" and the truth, which is that it rotated twice for somebody.
        lines.append("  in this Hermes process, across every conversation it is serving:")
        lines.append(
            "  {calls} call(s) · {rot} rotation(s) · {rec} recovered · {sur} surfaced".format(
                calls=getattr(binding, "calls", 0),
                rot=getattr(binding, "rotations", 0),
                rec=getattr(binding, "recovered", 0),
                sur=getattr(binding, "surfaced", 0),
            )
        )
        waits = getattr(binding, "waits", 0)
        if waits:
            lines.append(
                "  waited {dur} across {n} pause(s) rather than failing the turn".format(
                    dur=format_duration(getattr(binding, "waited_s", 0.0)), n=waits
                )
            )
        cuts = getattr(binding, "mid_stream_cuts", 0)
        if cuts:
            # The F2 diagnostic. Worth its four lines: this is the number that
            # explains "rewind stopped working", and there is nowhere else in
            # Hermes it can be read.
            lines.append(f"  {cuts} answer(s) cut mid-stream and handed back to Hermes")
            lines.append("    Each one makes Hermes append a continuation row the client")
            lines.append("    never shows, which is what makes rewind and edit refuse later")
            lines.append("    in a session. Raising HERMES_STREAM_STALE_TIMEOUT is the lever;")
            lines.append("    the ordinal arithmetic itself is the host's, not KAME's.")
        return lines

    def _pool_lines(self) -> List[str]:
        """Health per ``provider:model``, with the ETA when nothing is ready."""
        try:
            from .core.carousel import ENGINE

            pools: Dict[str, Dict[str, Any]] = ENGINE.snapshot()
        except Exception:
            logger.debug("kame: could not read the pool", exc_info=True)
            return ["Pool: could not be read — see the log."]
        if not pools:
            return [
                "Pool: nothing recorded yet — no call has failed this session,",
                "which is the state you want it in.",
            ]
        lines = ["Pool health, per provider and model:"]
        for identity in sorted(pools):
            row = pools[identity]
            detail = f"  {identity}: {row['healthy']}/{row['keys']} healthy"
            soonest = row.get("soonest")
            if soonest is not None:
                detail += f" — next key back in {format_duration(soonest)}"
            elif row.get("resting"):
                detail += f", {row['resting']} resting"
            if row.get("kinds"):
                detail += f" ({', '.join(row['kinds'])})"
            lines.append(detail)
        return lines

    def _host_lines(self) -> List[str]:
        """The four host variables, and what KAME did to them.

        Shown because two of them are set by this plugin at load time and a
        user reading "retries: 0" needs to know whether that was them, the
        host, or KAME.
        """
        try:
            from . import host_tuning

            claimed = host_tuning.described()
        except Exception:
            claimed = {}
        lines = ["Host settings KAME depends on:"]
        for name, default, what in _HOST_VARS:
            value = os.environ.get(name)
            shown = value if value is not None else f"{default} (host default)"
            mark = "  ← set by KAME" if name in claimed else ""
            lines.append(f"  {name:<28} {shown:<18} {what}{mark}")
        return lines

    def show(self) -> str:
        out: List[str] = [f"KAME API Rotation {__version__}"]
        out.append(f"loaded from {Path(__file__).resolve().parent}")
        out.append("")
        out.extend(self._rotation_lines())
        out.append("")
        out.extend(self._pool_lines())
        out.append("")
        out.extend(self._host_lines())
        out.append("")
        out.append("`/kame get` for KAME's own settings · `/kame set` to change one")
        return "\n".join(out)

    # -- settings ---------------------------------------------------------

    def get(self) -> str:
        rows = ["KAME settings — the value in force, and where it came from", ""]
        for key in settings.ALL_FLAGS:
            rows.append(
                f"  {key:<34} {str(settings.is_on(key)).lower():<9} {settings.provenance(key)}"
            )
        rows.append("")
        for key, default in settings.ALL_NUMBERS.items():
            value = settings.number(key, default)
            shown = f"{value:g}s" if value else "0 (off)"
            rows.append(f"  {key:<34} {shown:<9} {settings.provenance(key)}")
        rows.append("")
        rows.append("Precedence is environment, then config, then default. `/kame set`")
        rows.append("writes the environment one, so it takes effect on the next call and")
        rows.append("stays set after a restart. These are settings for the process, not")
        rows.append("for this chat: a change here applies to every conversation Hermes")
        rows.append("is serving, which is what a pool of keys shared between them needs.")
        return "\n".join(rows)

    def set(self, key: str, raw: str) -> str:
        key = key.strip()
        raw = raw.strip()
        if not settings.known(key):
            listing = "\n".join(
                f"  {name}" for name in list(settings.ALL_FLAGS) + list(settings.ALL_NUMBERS)
            )
            return f"Unknown setting `{key}`. KAME understands:\n{listing}"
        variable = settings.env_name(key)
        if not variable:
            return f"`{key}` has no environment variable, so it cannot be set from here."

        if key in settings.ALL_NUMBERS:
            try:
                number = float(raw)
            except (TypeError, ValueError):
                return f"`{key}` takes a number of seconds; `{raw}` is not one."
            value = str(int(number)) if number == int(number) else str(number)
        else:
            lowered = raw.lower()
            if lowered in {"1", "true", "yes", "on"}:
                value = "1"
            elif lowered in {"0", "false", "no", "off"}:
                value = "0"
            else:
                return f"`{key}` takes true or false; `{raw}` is neither."

        # The process environment first, so the change is live even if the
        # file write fails — a setting that took effect but was not persisted
        # is a much better outcome than one that did neither.
        os.environ[variable] = value
        ok, detail = _write_env(variable, value)
        head = (
            f"{key} = {settings.effective(key)!r}, in force from the next call, "
            "in every conversation this Hermes is serving"
        )
        if ok:
            return f"{head}\n{detail}\nNo restart needed."
        return (
            f"{head}\nNot made permanent: {detail}\n"
            f"To keep it across restarts, add `{variable}={value}` to Hermes' .env yourself."
        )

    # -- entry point ------------------------------------------------------

    def handle(self, raw_args: str = "") -> str:
        """Always returns text, never raises.

        A slash command that throws inside a chat turn is far worse than one
        that reports a problem.
        """
        try:
            parts = (raw_args or "").strip().split()
            if not parts:
                return self.show()
            verb = parts[0].lower()
            if verb in {"help", "-h", "--help", "?"}:
                return _HELP
            if verb in {"get", "settings", "config"}:
                return self.get()
            if verb == "set":
                if len(parts) < 3:
                    return "Usage: /kame set <key> <value>   (`/kame get` lists the keys)"
                return self.set(parts[1], " ".join(parts[2:]))
            return f"Unknown subcommand `{verb}`.\n\n{_HELP}"
        except Exception as exc:
            logger.debug("kame: /%s failed", COMMAND_NAME, exc_info=True)
            return f"/{COMMAND_NAME} failed: {type(exc).__name__}: {exc}"


def register_command(ctx, *, binding: Any = None) -> MenuCommand:
    command = MenuCommand(binding)
    ctx.register_command(
        COMMAND_NAME,
        command.handle,
        description=COMMAND_DESCRIPTION,
        args_hint=COMMAND_ARGS_HINT,
    )
    return command

"""The switches, read from where Hermes keeps switches.

This plugin's knobs were environment variables and nothing else,
which made them correct and invisible. Hermes has a place for exactly this:
a manifest declares ``config_schema``, the user writes
``plugins.entries.<id>.settings.<key>`` in ``config.yaml``, and the plugin
reads it back through ``ctx.get_config`` (``hermes_cli/plugins.py:1422``).
A knob that does not appear there is a knob nobody finds.

**The environment still wins.** ``KAME_ROTATION_DISABLED`` is the escape
hatch — the thing somebody reaches for when they suspect this plugin of
breaking their agent, from a shell, without editing a YAML file they may
never have created. A config file that could override it would make the
emergency switch conditional on the state it exists to rule out. So the
order is: environment if it says anything at all, config otherwise, and the
built-in default when neither speaks.

**Read once, at registration.** ``ctx.get_config`` calls
``load_config_readonly()`` on every access, and these are consulted on the
classification path and on the selection path — every failed call and every
credential handed out. A config file is re-read when Hermes restarts, which
is what changing a config file already means everywhere else in the host.

Nothing here can prevent the plugin from loading. A context without
``get_config``, a config that will not parse, a value of an unexpected type:
each falls back to the environment, which falls back to the default. The
failure mode of a switch must never be worse than the feature it switches.
"""

from __future__ import annotations

import logging
import os
from typing import Dict, Optional

logger = logging.getLogger(__name__)

# What counts as "on" when the value arrives as text — from the environment
# always, and from YAML when somebody quoted it. Booleans arrive as booleans.
_TRUE = frozenset({"1", "true", "yes", "on"})
_FALSE = frozenset({"0", "false", "no", "off"})

# key in config.yaml -> environment variable that outranks it
ROTATION_DISABLED = "disabled"
SPREAD_DISABLED = "spread_disabled"
FIELD_PROBE_DISABLED = "field_probe_disabled"
RESOLVER_DISABLED = "resolver_disabled"
CAROUSEL_DISABLED = "carousel_disabled"
# Every switch here turns a KAME behaviour *off*, which is why this one is
# named for the disabling rather than for the feature: collapsing is the
# default, as it is in Agent Zero, and ``is_on`` reads an absent setting as
# "off" — so a feature-named flag would default to not collapsing and the
# default would have to be spelled somewhere else to survive.
STORM_COLLAPSE_DISABLED = "storm_collapse_disabled"

_ENV_FOR = {
    ROTATION_DISABLED: "KAME_ROTATION_DISABLED",
    SPREAD_DISABLED: "KAME_SPREAD_DISABLED",
    FIELD_PROBE_DISABLED: "KAME_FIELD_PROBE_DISABLED",
    RESOLVER_DISABLED: "KAME_RESOLVER_DISABLED",
    CAROUSEL_DISABLED: "KAME_CAROUSEL_DISABLED",
    STORM_COLLAPSE_DISABLED: "KAME_STORM_COLLAPSE_DISABLED",
}

# The settings that carry a number rather than a yes/no. Kept in a separate
# table because they need a separate reader: a switch that cannot be parsed
# falls back to "off", which is harmless, while a *number* that cannot be
# parsed must fall back to the built-in default rather than to zero.
#
# There is deliberately no knob for how long the carousel may rotate. 1.0.0
# had one; 1.0.1 removed it along with the ceiling itself, for the reason
# Agent Zero's ADR 0002 gives for rejecting the same knob: any non-null value
# reintroduces the failure it was meant to prevent, and the user who sets a
# "safe" number hits it on a hard prompt and blames the plugin. Hermes already
# offers the bound at the level where it belongs — per request, via
# ``HERMES_API_TIMEOUT`` and the per-provider ``request_timeout_seconds``.
DAILY_COOLDOWN = "daily_quota_cooldown_seconds"

_NUMBER_ENV_FOR = {
    DAILY_COOLDOWN: "KAME_DAILY_COOLDOWN",
}

# Bounds, so a mistyped value cannot make the plugin worse than not having it.
# A daily cooldown of a second is a busy-loop against a key that is out until
# midnight; one over a day outlives the quota it describes.
_NUMBER_RANGE = {
    DAILY_COOLDOWN: (1.0, 86400.0),
}

# What the config file said, filled in once at registration. Empty until then,
# and empty forever on a host that offers no config surface — which is the
# same behaviour every version before this one had.
_FROM_CONFIG: Dict[str, bool] = {}
_NUMBERS_FROM_CONFIG: Dict[str, float] = {}


def _as_flag(value: object) -> Optional[bool]:
    """A truthy/falsy reading of one setting, or ``None`` for "said nothing".

    ``None`` matters as much as the two answers. An unset variable and a
    value nobody can interpret both mean the next source down should decide,
    and a setting that silently reads as ``False`` would make a typo look
    exactly like a deliberate "off".
    """
    if value is None:
        return None
    if isinstance(value, bool):
        return value
    text = str(value).strip().lower()
    if text in _TRUE:
        return True
    if text in _FALSE:
        return False
    return None


def _as_number(value: object, key: str) -> Optional[float]:
    """A bounded reading of one numeric setting, or ``None`` for "said nothing".

    Out-of-range is clamped rather than rejected: somebody who wrote
    ``daily_quota_cooldown_seconds: 99999`` meant "a long time", and refusing
    the whole setting over it would give them the default, which is shorter
    than anything they asked for.
    """
    if value is None or isinstance(value, bool):
        return None
    try:
        number = float(str(value).strip())
    except (TypeError, ValueError):
        return None
    low, high = _NUMBER_RANGE.get(key, (float("-inf"), float("inf")))
    return max(low, min(number, high))


def load(ctx) -> None:
    """Read every switch out of the host's config, once.

    Called from ``register``. Anything that goes wrong here leaves the
    plugin exactly as it was before config was a source at all.
    """
    _FROM_CONFIG.clear()
    _NUMBERS_FROM_CONFIG.clear()
    getter = getattr(ctx, "get_config", None)
    if not callable(getter):
        return
    for key in _NUMBER_ENV_FOR:
        try:
            raw = getter(key, None)
        except Exception:
            logger.debug("%s: could not read the %r setting", __name__, key, exc_info=True)
            continue
        number = _as_number(raw, key)
        if number is None:
            if raw is not None:
                logger.warning(
                    "kame: ignoring plugins.entries.hermes-kame-api-rotation"
                    ".settings.%s — expected a number of seconds",
                    key,
                )
            continue
        _NUMBERS_FROM_CONFIG[key] = number
    for key in _ENV_FOR:
        try:
            raw = getter(key, None)
        except Exception:
            # Includes the host rejecting the key outright, which it does by
            # raising. One unusable setting must not cost the other one.
            logger.debug("%s: could not read the %r setting", __name__, key, exc_info=True)
            continue
        flag = _as_flag(raw)
        if flag is None:
            if raw is not None:
                # Worth a line: the user wrote something and got the default.
                # Silently ignoring it is how a switch is reported broken.
                logger.warning(
                    "kame: ignoring plugins.entries.hermes-kame-api-rotation"
                    ".settings.%s — expected true or false",
                    key,
                )
            continue
        _FROM_CONFIG[key] = flag


def forget() -> None:
    """Drop what was read. For tests and for a re-registration."""
    _FROM_CONFIG.clear()
    _NUMBERS_FROM_CONFIG.clear()


def number(key: str, default: float) -> float:
    """A numeric setting, environment first, then config, then the default.

    Same precedence as ``is_on`` and for the same reason: the environment is
    what somebody reaches for when they are debugging a live gateway and do
    not want to edit — or create — a YAML file first.
    """
    from_env = _as_number(os.environ.get(_NUMBER_ENV_FOR.get(key, ""), None), key)
    if from_env is not None:
        return from_env
    return float(_NUMBERS_FROM_CONFIG.get(key, default))


def is_on(key: str) -> bool:
    """Whether the named switch is set, environment first.

    Defaults to ``False`` for each, which is the plugin doing its whole job:
    a switch that is not mentioned anywhere leaves every feature running.
    """
    from_env = _as_flag(os.environ.get(_ENV_FOR.get(key, ""), None))
    if from_env is not None:
        return from_env
    return bool(_FROM_CONFIG.get(key, False))

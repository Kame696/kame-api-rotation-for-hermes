/**
 * KAME API Rotation — the Desktop half.
 *
 * The Python plugin knows everything worth knowing about the pool and could,
 * until now, say none of it. A plugin slash command returns a string
 * (`hermes_cli/plugins.py`), and Desktop paints that string with
 * `pretty={false}` — so `/kame` is text, and text is the wrong shape for
 * "is my pool healthy right now". This file is the right shape: a status-bar
 * chip that is on screen at all times, and a real page at `/kame` with a row
 * in the sidebar, both built out of the app's own components so they look
 * like Hermes rather than like a plugin's idea of Hermes.
 *
 * HOW THE DATA GETS HERE. The Python half writes a small JSON document to
 * `<hermes home>/plugin-data/hermes-kame-api-rotation/state.json` (see
 * `state.py`) — fingerprints and counts, never key material. This file reads
 * it through the desktop bridge (`window.hermesDesktop.readFileText`) on a
 * one-second tick. No backend route, nothing to enable, nothing to restart:
 * the alternative, `plugin_api.py` behind `dashboard/plugin.json` and an
 * `plugins.enabled` entry, is the door for a plugin built around a dashboard,
 * not for one the user already has running.
 *
 * WHY THE COUNTDOWN IS COMPUTED HERE. The snapshot carries `soonest_s` at
 * `updated_at`, not a wall-clock deadline. The Python side publishes when
 * something happens and on a slow heartbeat, so between publishes the number
 * on disk is stale by exactly the snapshot's age — which is why every ETA on
 * screen is `soonest_s - (now - updated_at)`, clamped at zero. A countdown
 * that freezes for twenty seconds and then jumps is the same freeze the whole
 * feature exists to remove.
 *
 * WHERE IT LIVES ON DISK. `<hermes home>/desktop-plugins/hermes-kame-api-rotation/plugin.js`
 * — the standalone runtime door, which loads default-on. The unified door
 * (`plugins/<name>/desktop/plugin.js`) is deliberately NOT used: it ships
 * `defaultEnabled: false` to match the Python half's installed-but-inert
 * posture, so the chip would be invisible until someone found the toggle,
 * which is the exact problem this release is fixing.
 *
 * This file is plain ESM. It may import `@hermes/plugin-sdk` and `react` and
 * nothing else — the loader rewrites those two specifiers and rejects the
 * rest.
 */

import {
  atom,
  cn,
  host,
  PALETTE_AREA,
  ROUTES_AREA,
  SIDEBAR_NAV_AREA,
  STATUSBAR_AREAS,
  StatusDot,
  Tip,
  useValue
} from '@hermes/plugin-sdk'
import { jsx, jsxs } from 'react/jsx-runtime'

const PLUGIN_ID = 'hermes-kame-api-rotation'
const ROUTE = '/kame'

/** Schema of `state.json` this UI understands. A document from a newer Python
 *  half is refused with a readable reason rather than half-rendered. */
const SCHEMA = 1

/** How often the snapshot is re-read, and how often the countdowns move.
 *  One second because that is the resolution of a countdown a person reads;
 *  the read is a few hundred bytes off a local disk. */
const TICK_MS = 1000

/** Older than this and the reading is presented as stale rather than as
 *  truth. The Python half republishes at least every 20s, so a minute of
 *  silence means the process is gone, wedged, or was never there. */
const STALE_AFTER_S = 75

// -- state ------------------------------------------------------------------

/** The parsed document, or null when there is nothing to show. */
const $snapshot = atom(null)

/** Why there is nothing to show. Empty while the snapshot is readable. */
const $problem = atom('')

/** A one-second clock, so countdowns move between snapshot reads. */
const $now = atom(Date.now())

// -- helpers ----------------------------------------------------------------

/**
 * `jsx`/`jsxs` with a children-shaped call signature.
 *
 * Hand-written runtime JSX is easy to get subtly wrong — `jsx` for one child,
 * `jsxs` for several, and `key` as the third argument rather than a prop.
 * Wrapping it once means the rest of this file reads like markup.
 */
function h(type, props, ...rest) {
  const children = rest.flat().filter(child => child !== null && child !== undefined && child !== false)
  const { key, ...attrs } = props ?? {}

  if (children.length === 0) {
    return jsx(type, attrs, key)
  }

  if (children.length === 1) {
    return jsx(type, { ...attrs, children: children[0] }, key)
  }

  return jsxs(type, { ...attrs, children }, key)
}

/** `1h 02m`, `4m 12s`, `38s`. Matches the Python side's `format_duration`, so
 *  the chip and `/kame` never disagree about the same number. */
function duration(seconds) {
  const total = Math.max(0, Math.round(seconds ?? 0))

  if (total < 60) {
    return `${total}s`
  }

  const minutes = Math.floor(total / 60)

  if (minutes < 60) {
    return `${minutes}m ${String(total % 60).padStart(2, '0')}s`
  }

  return `${Math.floor(minutes / 60)}h ${String(minutes % 60).padStart(2, '0')}m`
}

/** Seconds since the snapshot was written, from the app's own clock. */
function ageSeconds(document, now) {
  if (!document?.updated_at) {
    return Number.POSITIVE_INFINITY
  }

  return Math.max(0, now / 1000 - document.updated_at)
}

/**
 * The live countdown to the first key coming back, or null when a key is
 * usable now.
 *
 * `value` is what the Python half measured at `updated_at`; the age is
 * subtracted here so the number on screen is the number right now.
 */
function countdown(value, document, now) {
  if (value === null || value === undefined) {
    return null
  }

  return Math.max(0, value - ageSeconds(document, now))
}

function toneFor(document, now) {
  if (!document || ageSeconds(document, now) > STALE_AFTER_S) {
    return 'muted'
  }

  if (!document.installed) {
    return 'muted'
  }

  const totals = document.totals ?? {}

  if (!totals.keys) {
    return 'muted'
  }

  if (!totals.healthy) {
    return 'bad'
  }

  return totals.healthy < totals.keys ? 'warn' : 'good'
}

// -- the reader -------------------------------------------------------------

/**
 * Where the Python half writes.
 *
 * Derived from the bridge's own plugin roots rather than from `HERMES_HOME`,
 * because the renderer is Electron-local and the backend's idea of home can
 * be a different machine entirely. `desktop-plugins` and `plugins` are both
 * direct children of the Hermes home, so either one names the parent.
 */
async function snapshotPath() {
  const desktop = window.hermesDesktop

  if (!desktop) {
    return null
  }

  const root = (await desktop.desktopPluginsRoot?.()) || (await desktop.agentPluginsRoot?.())

  if (!root) {
    return null
  }

  const home = String(root).replace(/[\\/]+(?:desktop-plugins|plugins)[\\/]*$/, '')

  return `${home}/plugin-data/${PLUGIN_ID}/state.json`
}

let cachedPath = null

async function readSnapshot() {
  const desktop = window.hermesDesktop

  if (!desktop?.readFileText) {
    $snapshot.set(null)
    $problem.set('This Hermes shell has no file bridge, so the pool cannot be read.')

    return
  }

  cachedPath ??= await snapshotPath()

  if (!cachedPath) {
    $problem.set('This Hermes shell reports no plugin root, so the snapshot cannot be located.')

    return
  }

  let text

  try {
    ;({ text } = await desktop.readFileText(cachedPath))
  } catch {
    // Absent is the ordinary case on a fresh install, and on any Hermes
    // running a KAME older than 1.1.0 — say which, rather than "error".
    $snapshot.set(null)
    $problem.set('No snapshot yet. KAME 1.1.0 or newer writes one as soon as the backend loads it.')

    return
  }

  let document

  try {
    document = JSON.parse(text)
  } catch {
    // A torn read should be impossible (the writer is atomic), so this is a
    // real corruption — but it is also self-healing, so it stays quiet and
    // waits for the next tick rather than clearing a good reading.
    $problem.set('The snapshot could not be parsed. Waiting for the next write.')

    return
  }

  if (document?.schema !== SCHEMA) {
    $snapshot.set(null)
    $problem.set(
      `The installed KAME writes snapshot schema ${document?.schema ?? '?'}; this panel reads ${SCHEMA}. ` +
        'Update the desktop half to match.'
    )

    return
  }

  $snapshot.set(document)
  $problem.set('')
}

/** Start the tick. Returns a disposer, so a reload of this plugin leaves no
 *  timer behind. */
function startReading() {
  let stopped = false

  const tick = () => {
    if (stopped) {
      return
    }

    $now.set(Date.now())

    // A hidden window has nothing to render, and the reading is worthless the
    // moment it comes back anyway — but the clock keeps running so the first
    // frame after a focus is already correct.
    if (typeof document !== 'undefined' && document.visibilityState !== 'visible') {
      return
    }

    void readSnapshot()
  }

  tick()

  const timer = window.setInterval(tick, TICK_MS)

  return () => {
    stopped = true
    window.clearInterval(timer)
  }
}

// -- the status bar chip ----------------------------------------------------

/**
 * Always on screen: pool health, and the countdown when the pool is resting.
 *
 * The ask this answers, in the user's words: knowing at a glance that nothing
 * is frozen — "sempre que possivel que nao estiver processando, pensando ou
 * fazendo algo ... der pra ver diretamente e ter noção da saúde e toda vez que
 * estiver em um ETA aparecer também". So it renders between turns too, not
 * only while a request is in flight.
 */
function KameChip() {
  const document = useValue($snapshot)
  const problem = useValue($problem)
  const now = useValue($now)

  const totals = document?.totals ?? {}
  const activity = document?.activity ?? null
  const age = ageSeconds(document, now)
  const stale = age > STALE_AFTER_S
  const tone = toneFor(document, now)

  let label = '—'
  let detail = ''

  if (document?.installed && totals.keys) {
    label = `${totals.healthy}/${totals.keys}`

    const eta = countdown(totals.soonest_s, document, now)

    if (activity?.kind === 'calling' && activity.attempt > 1) {
      detail = `key ${activity.attempt}`
    } else if (activity?.kind === 'waiting') {
      detail = duration(countdown(activity.eta_s, document, now) ?? 0)
    } else if (eta !== null) {
      detail = duration(eta)
    }
  }

  const lines = []

  if (problem) {
    lines.push(problem)
  } else if (!document?.installed) {
    lines.push(`KAME is loaded but not rotating: ${document?.reason ?? 'unknown'}`)
  } else {
    lines.push(`${totals.healthy} of ${totals.keys} keys ready`)

    for (const pool of document.pools ?? []) {
      const eta = countdown(pool.soonest_s, document, now)

      lines.push(
        `${pool.identity}: ${pool.healthy}/${pool.keys}` + (eta === null ? '' : `, next key in ${duration(eta)}`)
      )
    }

    if (activity?.kind === 'calling') {
      lines.push(`Calling ${activity.model} on attempt ${activity.attempt}`)
    } else if (activity?.kind === 'waiting') {
      lines.push('Every key is resting — waiting rather than failing the turn')
    }

    lines.push(`${document.counters?.rotations ?? 0} rotations, ${document.counters?.recovered ?? 0} recovered`)
  }

  if (stale && document) {
    lines.push(`Last reading ${duration(age)} old — the backend may be down.`)
  }

  lines.push('Click for the full panel')

  return h(
    Tip,
    { label: lines.join('\n') },
    h(
      'button',
      {
        className: cn(
          'inline-flex h-full items-center gap-1 rounded-none px-1.5 text-[0.6875rem] tabular-nums transition-colors',
          'text-(--ui-text-tertiary) hover:bg-(--chrome-action-hover) hover:text-foreground',
          stale && 'opacity-60'
        ),
        onClick: () => host.navigate(ROUTE),
        type: 'button'
      },
      h(StatusDot, { tone }),
      h('span', null, 'KAME'),
      h('span', null, label),
      detail && h('span', { className: 'text-(--ui-text-quaternary)' }, `· ${detail}`)
    )
  )
}

// -- the page ---------------------------------------------------------------

function Card(props, ...children) {
  return h(
    'section',
    {
      className: cn(
        'rounded-lg border border-(--ui-stroke-tertiary) bg-(--ui-bg-tertiary)/40 p-4',
        props?.className
      ),
      key: props?.key
    },
    props?.title &&
      h('h2', { className: 'text-xs font-medium tracking-wide text-(--ui-text-secondary) uppercase' }, props.title),
    props?.note && h('p', { className: 'mt-1 text-xs text-(--ui-text-quaternary)' }, props.note),
    h('div', { className: 'mt-3' }, ...children)
  )
}

function Field(label, value, hint) {
  return h(
    'div',
    { className: 'flex items-baseline justify-between gap-3 py-1', key: label },
    h('span', { className: 'text-xs text-(--ui-text-tertiary)' }, label),
    h(
      'span',
      { className: 'text-right text-xs tabular-nums text-(--ui-text-primary)' },
      value,
      hint && h('span', { className: 'ml-2 text-(--ui-text-quaternary)' }, hint)
    )
  )
}

/** One pool, with the bar that makes "12 of 15" readable without arithmetic. */
function PoolRow({ pool, document, now }) {
  const ratio = pool.keys ? pool.healthy / pool.keys : 0
  const eta = countdown(pool.soonest_s, document, now)

  return h(
    'div',
    { className: 'py-2', key: pool.identity },
    h(
      'div',
      { className: 'flex items-baseline justify-between gap-3' },
      h('span', { className: 'font-mono text-xs text-(--ui-text-primary)' }, pool.identity),
      h(
        'span',
        { className: 'text-xs tabular-nums text-(--ui-text-tertiary)' },
        `${pool.healthy}/${pool.keys} ready`,
        eta !== null && h('span', { className: 'ml-2 text-(--ui-text-quaternary)' }, `next in ${duration(eta)}`)
      )
    ),
    h(
      'div',
      { className: 'mt-1.5 h-1 w-full overflow-hidden rounded-full bg-(--ui-bg-quinary)' },
      h('div', {
        className: cn(
          'h-full rounded-full transition-[width] duration-500',
          ratio === 1 ? 'bg-primary' : ratio > 0 ? 'bg-amber-500' : 'bg-destructive'
        ),
        style: { width: `${Math.round(ratio * 100)}%` }
      })
    ),
    Boolean(pool.kinds?.length || pool.successes || pool.failures) &&
      h(
        'div',
        { className: 'mt-1 flex flex-wrap gap-x-3 text-[0.6875rem] text-(--ui-text-quaternary)' },
        h('span', null, `${pool.successes} answered · ${pool.failures} refused`),
        pool.kinds?.length ? h('span', null, pool.kinds.join(', ')) : null
      )
  )
}

/** What KAME is doing this second — the whole point of the page being live. */
function RightNow({ document, now }) {
  const activity = document.activity
  const totals = document.totals ?? {}

  if (!activity) {
    const eta = countdown(totals.soonest_s, document, now)

    return h(
      'p',
      { className: 'text-sm text-(--ui-text-secondary)' },
      eta === null
        ? 'Idle. A key is ready, so the next call goes straight out.'
        : `Idle, and every key is resting. The first one comes back in ${duration(eta)}.`
    )
  }

  if (activity.kind === 'calling') {
    return h(
      'p',
      { className: 'text-sm text-(--ui-text-secondary)' },
      activity.attempt > 1
        ? `Rotated. Attempt ${activity.attempt} on ${activity.model}, with ${activity.healthy} of ${activity.keys} keys still ready.`
        : `Calling ${activity.model}, with ${activity.healthy} of ${activity.keys} keys ready.`
    )
  }

  if (activity.kind === 'waiting') {
    const eta = countdown(activity.eta_s, document, now)

    return h(
      'p',
      { className: 'text-sm text-(--ui-text-secondary)' },
      `Every key is resting. Waiting ${eta === null ? 'for one to come back' : duration(eta)} rather than failing the turn — press Esc to stop.`
    )
  }

  if (activity.kind === 'recovered') {
    return h(
      'p',
      { className: 'text-sm text-(--ui-text-secondary)' },
      `Answered after ${duration(activity.waited_s)} of waiting, on ${activity.model}.`
    )
  }

  return h('p', { className: 'text-sm text-(--ui-text-secondary)' }, 'Working.')
}

function KamePage() {
  const document = useValue($snapshot)
  const problem = useValue($problem)
  const now = useValue($now)

  const header = (right) =>
    h(
      'header',
      { className: 'flex flex-wrap items-baseline justify-between gap-3' },
      h(
        'div',
        { className: 'flex items-baseline gap-2' },
        h('h1', { className: 'text-lg font-medium text-(--ui-text-primary)' }, 'KAME API Rotation'),
        document?.version && h('span', { className: 'text-xs text-(--ui-text-quaternary)' }, `v${document.version}`)
      ),
      right
    )

  if (!document) {
    return h(
      'div',
      { className: 'flex h-full w-full flex-col gap-4 overflow-y-auto p-6' },
      header(null),
      h(
        'p',
        { className: 'text-sm text-(--ui-text-tertiary)' },
        problem || 'Reading the pool…'
      ),
      h(
        'p',
        { className: 'text-xs text-(--ui-text-quaternary)' },
        'This page reads a file the backend half of KAME writes. If Hermes has just started, give it a moment.'
      )
    )
  }

  const totals = document.totals ?? {}
  const counters = document.counters ?? {}
  const age = ageSeconds(document, now)
  const stale = age > STALE_AFTER_S
  const repair = document.gemini_tool_call_fix ?? {}

  return h(
    'div',
    { className: 'flex h-full w-full flex-col gap-4 overflow-y-auto p-6' },

    header(
      h(
        'div',
        { className: 'flex items-center gap-2 text-xs text-(--ui-text-tertiary)' },
        h(StatusDot, { tone: toneFor(document, now) }),
        h(
          'span',
          null,
          document.installed ? `${totals.healthy} of ${totals.keys} keys ready` : 'not rotating'
        ),
        h(
          'span',
          { className: cn('text-(--ui-text-quaternary)', stale && 'text-(--ui-red)') },
          stale ? `reading ${duration(age)} old` : 'live'
        )
      )
    ),

    !document.installed &&
      h(
        'p',
        { className: 'rounded-md border border-(--ui-stroke-tertiary) p-3 text-sm text-(--ui-text-secondary)' },
        `KAME is loaded but every call keeps the key Hermes resolved: ${document.reason}`
      ),

    stale &&
      h(
        'p',
        { className: 'rounded-md border border-(--ui-stroke-tertiary) p-3 text-sm text-(--ui-text-secondary)' },
        `Nothing has been written for ${duration(age)}. The numbers below are the last reading, not the current one — ` +
          'the backend is probably restarting.'
      ),

    Card({ title: 'Right now' }, h(RightNow, { document, now })),

    Card(
      { title: 'Pool health', note: 'One pool per provider and model. A key spent on one model keeps its allowance on another.' },
      (document.pools ?? []).length
        ? (document.pools ?? []).map(pool => h(PoolRow, { document, key: pool.identity, now, pool }))
        : h(
            'p',
            { className: 'text-sm text-(--ui-text-tertiary)' },
            'Nothing recorded yet — no call has failed this session, which is the state you want it in.'
          )
    ),

    Card(
      {
        title: 'This Hermes process',
        note: 'Across every conversation it is serving, including subagents and the auxiliary lane.'
      },
      Field('Calls', counters.calls ?? 0),
      Field('Rotations', counters.rotations ?? 0),
      Field('Recovered', counters.recovered ?? 0, 'answered after a rotation'),
      Field('Surfaced', counters.surfaced ?? 0, 'errors KAME let through'),
      counters.waits ? Field('Waited', duration(counters.waited_s), `across ${counters.waits} pause(s)`) : null,
      counters.mid_stream_cuts
        ? Field('Cut mid-stream', counters.mid_stream_cuts, 'handed back to Hermes')
        : null
    ),

    Card(
      {
        title: 'Gemini parallel tool calls',
        note: 'Two parallel calls to one tool arrive under the same slot and their arguments are concatenated, which Hermes reports as "Response truncated due to output length limit".'
      },
      Field('Repair', repair.applied ? 'in place' : 'not applied', repair.applied ? null : repair.reason),
      repair.applied ? Field('Calls separated', repair.repaired ?? 0) : null
    ),

    (document.settings ?? []).length
      ? Card(
          { title: 'Settings', note: 'Read-only here. Change one with /kame set <key> <value> — it takes effect on the next call and survives a restart.' },
          (document.settings ?? []).map(setting =>
            Field(
              setting.key,
              setting.kind === 'flag' ? String(setting.value) : setting.value ? `${setting.value}s` : 'off',
              setting.source
            )
          )
        )
      : null,

    h(
      'footer',
      { className: 'pb-2 text-[0.6875rem] text-(--ui-text-quaternary)' },
      h('p', null, `Backend process ${document.pid} · reading refreshed every second`),
      h('p', { className: 'mt-1' }, '/kame for the same picture in the chat, /kame-quota per key and model, /kame-keys to add keys in bulk')
    )
  )
}

// -- registration -----------------------------------------------------------

export default {
  id: PLUGIN_ID,
  name: 'KAME API Rotation',
  description: 'Live key-pool health, rotation and recovery countdowns — a status-bar chip and a full panel.',
  register(ctx) {
    ctx.onDispose(startReading())

    ctx.registerMany([
      {
        id: 'chip',
        area: STATUSBAR_AREAS.right,
        order: 90,
        render: () => h(KameChip, null)
      },
      {
        id: 'page',
        area: ROUTES_AREA,
        title: 'KAME',
        data: { path: ROUTE },
        render: () => h(KamePage, null)
      },
      {
        id: 'nav',
        area: SIDEBAR_NAV_AREA,
        order: 60,
        data: { codicon: 'sync', label: 'KAME', path: ROUTE }
      },
      {
        id: 'open',
        area: PALETTE_AREA,
        data: {
          id: 'kame.open',
          label: 'KAME: Open rotation panel',
          keywords: ['kame', 'rotation', 'keys', 'quota', 'pool', 'api'],
          run: () => host.navigate(ROUTE)
        }
      }
    ])
  }
}

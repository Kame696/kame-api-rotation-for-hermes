"""Every API call picks its own key, and a failed call rotates instead of failing.

This is the binding the plugin was missing. Everything before it acted *after*
a refusal — size the cooldown, bench the key, hand the pool a better reset time.
None of that chooses the key a request carries, and none of it survives Hermes'
own retry ceiling.

Where this attaches
-------------------

``run_agent.py`` routes every model call through two forwarders::

    def _interruptible_streaming_api_call(self, api_kwargs, *, on_first_delta=None):
        from agent.chat_completion_helpers import interruptible_streaming_api_call
        return interruptible_streaming_api_call(self, api_kwargs, on_first_delta=on_first_delta)

    def _interruptible_api_call(self, api_kwargs):
        from agent.chat_completion_helpers import interruptible_api_call
        return interruptible_api_call(self, api_kwargs)

Both import the module function **inside the method body**, so replacing the
module attribute reaches every caller in the process — the main loop, the
auxiliary lane, compression, subagents, the gateway and the CLI alike — without
touching a class, a subclass, or an instance. It is the same property that
makes ``resolve_runtime_provider`` wrappable, and it is why this plugin can own
the dispatch point without patching Hermes.

What it does per call
---------------------

1. Collect the keys this agent could use — the credential pool's entries when
   there is one, otherwise a comma-split of ``agent.api_key``.
2. Ask :mod:`core.carousel` which one is healthiest *right now*: fewest requests
   in the last 60 seconds, least recently used to break the tie.
3. Put that key on the agent (cheaply — see ``_apply_key``) and call the host's
   own function. KAME does not re-implement the request, exactly as Agent Zero
   v1.0.9 stopped doing: the streaming, the interrupts, the middleware, the
   response shape all stay Hermes'.
4. On success, clear the key's health and return the host's own result.
5. On failure, classify it, rest the key for as long as the evidence justifies,
   and **take the next key** — without the error ever reaching the conversation
   loop, which is what stops it reaching the chat.

Why the loop lives here and not in the host
-------------------------------------------

Hermes retries ``agent._api_max_retries`` times (default **3**) and rotates the
credential pool only for ``billing``, ``rate_limit`` and ``auth``
(``agent_runtime_helpers.recover_with_credential_pool``). A 503 is none of
those, so the observed failure — three 503s and a dead turn, with fourteen
untouched keys in the pool — is the host behaving exactly as designed. Raising
the retry ceiling alone would not fix it either, because the retries would all
go to the same key.

So the carousel runs *inside* one host retry. From the conversation loop's
point of view a call either succeeds or fails once; the fifteen keys it tried
in between are this module's business.

The two limits on that promise, both deliberate
-----------------------------------------------

**A partial stream is never replayed.** If the provider delivered tokens and
then dropped, the user has already seen text. Retrying here would print the
answer twice. That failure is re-raised to the host, which has machinery for
exactly it (the ``[System: The previous response was cut off…]`` continuation).
``_progress`` is how the wrapper knows: the delta callbacks are shimmed for the
duration of the attempt, so "nothing arrived yet" is observed rather than
assumed. This mirrors the ``progress["any"]`` flag Agent Zero's v1.0.9 carousel
introduced for the same reason.

**A terminal error is still terminal.** A malformed request, a 404 model, a
content-policy refusal: no key answers those, and rotating through fifteen of
them would turn one clear error into fifteen slow ones. ``core.carousel.is_terminal``
draws the line, and it checks *auth before status* — Google reports an invalid
key as ``400 INVALID_ARGUMENT: API key not valid``, which every status-first
classifier reads as a permanent client error and aborts the run on. Here it
quarantines that one key and rotates, which is the difference between a dead
session and a turn that finishes on the other fourteen.

Switching it off
----------------

``KAME_CAROUSEL_DISABLED=1`` (or ``carousel_disabled`` in the plugin's config
entry) removes the wrapper's effect entirely and leaves Hermes' own retry and
rotation in charge.
"""

from __future__ import annotations

import functools
import logging
import sys
import time
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple

from . import settings
from .core import multikey
from .core.carousel import (
    EMPTY_REST_S,
    EMPTY_RETRY_BUDGET,
    ENGINE,
    Carousel,
    classify,
    fingerprint,
    format_duration,
    is_auth_failure,
    is_terminal,
)

logger = logging.getLogger(__name__)

_MARK = "__kame_carousel__"

_MODULE = "agent.chat_completion_helpers"

#: Both dispatch functions, wrapped identically. The streaming one carries an
#: ``on_first_delta`` keyword; the wrapper forwards ``**kwargs`` untouched so a
#: future Hermes adding a parameter cannot break it.
_FUNCTIONS = ("interruptible_streaming_api_call", "interruptible_api_call")

#: Raised to mean "the user pressed the button", not "the provider failed".
#: Retrying these would ignore an interrupt, so they pass straight through.
_CONTROL_FLOW = (KeyboardInterrupt, SystemExit, GeneratorExit, InterruptedError)

#: How long one call may spend rotating before the failure is handed to the
#: host. Agent Zero's carousel is unbounded; a chat UI is not, and a turn that
#: never returns is indistinguishable from a hang. Overridable.
DEFAULT_DEADLINE_S = 600.0

#: Longest single sleep while the whole pool is resting. Slept in one-second
#: slices so an interrupt is honoured within a second, and re-checked after so
#: a key that recovers early is used immediately.
_SLEEP_SLICE_S = 1.0
_MAX_SLEEP_S = 60.0


class Incompatible(Exception):
    """The installed Hermes does not present the surface this module needs."""


# --- reading the agent ------------------------------------------------------


def _entries_of(agent: Any) -> List[Any]:
    """The credential pool's entries, or an empty list.

    Entries are preferred over raw strings because they carry a base URL and an
    id, which is what ``_apply_key`` needs to swap a key correctly on the
    Anthropic path. Everything is guarded: this runs on the hot path of every
    API call, and no read of an arbitrary host object is allowed to cost a turn.
    """
    pool = getattr(agent, "_credential_pool", None)
    if pool is None:
        return []
    try:
        entries = list(pool.entries())
    except Exception:
        return []
    usable = []
    for entry in entries:
        try:
            key = getattr(entry, "runtime_api_key", None) or getattr(entry, "access_token", "")
        except Exception:
            continue
        if str(key or "").strip():
            usable.append(entry)
    return usable


def _key_of(entry: Any) -> str:
    try:
        value = getattr(entry, "runtime_api_key", None) or getattr(entry, "access_token", "")
    except Exception:
        return ""
    return str(value or "").strip()


def candidates(agent: Any) -> Tuple[List[str], Dict[str, Any]]:
    """``(keys, entry_by_key)`` — everything this agent is allowed to send.

    Three sources, in order of authority:

    * the credential pool, which is where a Hermes that was configured through
      the UI keeps them;
    * a comma-separated ``agent.api_key``, which is where a Hermes configured
      through an environment variable keeps them, and which the resolver
      binding has already reduced to one key for the *first* call of a session
      but not for the rest;
    * the single resolved key, which is not a pool at all — the carousel still
      earns its keep there, because backoff and eternal retry apply to one key
      just as they do to fifteen.
    """
    entry_by_key: Dict[str, Any] = {}
    keys: List[str] = []
    for entry in _entries_of(agent):
        key = _key_of(entry)
        if key and key not in entry_by_key:
            entry_by_key[key] = entry
            keys.append(key)

    current = str(getattr(agent, "api_key", "") or "").strip()
    if not keys:
        split, _rejected = multikey.split_value(current)
        keys = split if len(split) > 1 else ([current] if current else [])
    elif current and current not in entry_by_key:
        # The agent is carrying a key the pool does not know — a resolver
        # substitution, a fallback provider, a manually set key. It is a
        # working credential and dropping it would narrow what the host would
        # have sent, which this plugin never does.
        keys.append(current)
    return keys, entry_by_key


def _apply_key(agent: Any, key: str, entry: Any) -> bool:
    """Put ``key`` on the agent for the next request. ``True`` if it took.

    The cheap path is the one Hermes itself uses when it rewrites a key
    mid-loop (``conversation_loop.py``, the non-ASCII sanitiser): assign
    ``api_key``, keep ``_client_kwargs`` in step, and update the live client,
    which reads its own copy when it builds auth headers on every request. No
    client is rebuilt, because every key in a pool shares the provider's base
    URL — rebuilding one client per call would cost more than the rotation
    saves.

    The Anthropic path cannot do that: ``build_anthropic_client`` bakes the key
    into the client at construction. There, and only there, the host's own
    ``_swap_credential`` is used, and only when a pool entry is available to
    hand it. Rotating on that path costs a client rebuild; not rotating would
    be a silent lie about what the plugin does.
    """
    if not key:
        return False
    if str(getattr(agent, "api_key", "") or "") == key:
        # Already carrying it — nothing to write, but the attribution still
        # has to be right. If this call does fail into the host, Hermes reads
        # ``_credential_pool_entry_id`` to decide which entry to bench, and a
        # stale id from a previous rotation would bench a healthy key.
        _attribute(agent, entry)
        return True

    if getattr(agent, "api_mode", "") == "anthropic_messages":
        swap = getattr(agent, "_swap_credential", None)
        if entry is None or not callable(swap):
            return False
        try:
            swap(entry)
            return True
        except Exception:
            logger.debug("kame: could not swap the Anthropic credential", exc_info=True)
            return False

    try:
        agent.api_key = key
        client_kwargs = getattr(agent, "_client_kwargs", None)
        if isinstance(client_kwargs, dict):
            client_kwargs["api_key"] = key
        client = getattr(agent, "client", None)
        if client is not None and hasattr(client, "api_key"):
            client.api_key = key
        _attribute(agent, entry)
        return True
    except Exception:
        logger.debug("kame: could not place the selected key on the agent", exc_info=True)
        return False


def _attribute(agent: Any, entry: Any) -> None:
    """Tell the host which pool entry sent this request.

    Hermes reads ``_credential_pool_entry_id`` when it benches a credential
    (``agent_runtime_helpers.recover_with_credential_pool``). Leaving it
    pointing at the previous rotation's entry would bench a healthy key for a
    failure it never had — the exact mis-attribution the host's own code goes
    out of its way to avoid.
    """
    if entry is None:
        return
    try:
        entry_id = getattr(entry, "id", None)
        if isinstance(entry_id, str) and entry_id:
            agent._credential_pool_entry_id = entry_id
    except Exception:  # pragma: no cover — a plain attribute write
        pass


# --- watching the stream ----------------------------------------------------


class _Progress:
    """Flipped the instant anything reaches the user.

    The wrapper cannot count tokens — it does not own the stream any more than
    Agent Zero's v1.0.9 carousel does. It watches the callbacks instead, and
    every shim returns whatever the real callback returned, because Hermes uses
    those return values to control early stopping.
    """

    __slots__ = ("any",)

    def __init__(self) -> None:
        self.any = False


def _shim(progress: _Progress, callback: Any) -> Any:
    if not callable(callback):
        return callback

    @functools.wraps(callback)
    def _watched(*args, **kwargs):
        progress.any = True
        return callback(*args, **kwargs)

    return _watched


def _install_shims(agent: Any, progress: _Progress, kwargs: Dict[str, Any]) -> Dict[str, Any]:
    """Wrap every delivery callback for one attempt; returns what to restore."""
    restore: Dict[str, Any] = {}
    for name in ("stream_delta_callback", "_stream_callback", "thinking_callback"):
        original = getattr(agent, name, None)
        if callable(original):
            restore[name] = original
            try:
                setattr(agent, name, _shim(progress, original))
            except Exception:
                restore.pop(name, None)
    if callable(kwargs.get("on_first_delta")):
        kwargs["on_first_delta"] = _shim(progress, kwargs["on_first_delta"])
    return restore


def _remove_shims(agent: Any, restore: Dict[str, Any]) -> None:
    for name, original in restore.items():
        try:
            setattr(agent, name, original)
        except Exception:  # pragma: no cover — the setattr that worked once
            pass


def _interrupted(agent: Any) -> bool:
    try:
        return bool(getattr(agent, "_interrupt_requested", False))
    except Exception:
        return False


def _result_is_empty(result: Any) -> bool:
    """Whether the host's answer carried no content at all.

    A squeezed free-tier key returns 200 and nothing rather than refusing. The
    first such answer from a key is treated as a provider hiccup and costs the
    key nothing; the rule for the second one lives in the carousel loop.
    """
    if result is None:
        return True
    try:
        choices = getattr(result, "choices", None)
        if choices:
            message = getattr(choices[0], "message", None)
            content = getattr(message, "content", None) if message is not None else None
            tool_calls = getattr(message, "tool_calls", None) if message is not None else None
            if tool_calls:
                return False
            return not str(content or "").strip()
        content = getattr(result, "content", None)
        if isinstance(content, str):
            return not content.strip()
        if isinstance(content, list):
            return not any(
                str(getattr(part, "text", "") or "").strip() for part in content
            )
    except Exception:
        return False
    return False


# --- the binding ------------------------------------------------------------


class DispatchBinding:
    """Installs, owns, and can fully remove the per-call carousel."""

    def __init__(
        self,
        *,
        deadline_s: float = DEFAULT_DEADLINE_S,
        engine: Optional[Carousel] = None,
    ) -> None:
        self._module: Any = None
        self._originals: Dict[str, Callable] = {}
        self.installed = False
        self.reason = "not installed"
        self.deadline_s = float(deadline_s)
        self.engine = engine or ENGINE
        # For ``/kame-quota``: an install that has never rotated and one that
        # is silently inert are otherwise indistinguishable.
        self.calls = 0
        self.rotations = 0
        self.recovered = 0
        self.surfaced = 0

    # -- lifecycle -------------------------------------------------------

    def install(self, module: Any) -> bool:
        """Wrap both dispatch functions. Never raises; a refusal is an outcome."""
        if self.installed:
            return True
        if module is None:
            self.reason = f"{_MODULE} is not importable in this process"
            logger.info("kame: every call keeps the host's key — %s", self.reason)
            return False

        originals: Dict[str, Callable] = {}
        for name in _FUNCTIONS:
            function = getattr(module, name, None)
            if not callable(function):
                self.reason = f"{_MODULE} has no {name}()"
                logger.info("kame: every call keeps the host's key — %s", self.reason)
                return False
            if getattr(function, _MARK, False):
                self.reason = "already wrapped by another KAME instance"
                logger.debug("kame: %s", self.reason)
                return False
            originals[name] = function

        self._module = module
        self._originals = originals
        for name, original in originals.items():
            setattr(module, name, self._wrap(original))
        self.installed = True
        self.reason = "active"
        logger.info(
            "kame: every API call picks the healthiest key and rotates on failure "
            "(deadline %s)",
            format_duration(self.deadline_s),
        )
        return True

    def uninstall(self) -> None:
        if not self.installed or self._module is None:
            return
        for name, original in self._originals.items():
            if getattr(getattr(self._module, name, None), _MARK, False):
                setattr(self._module, name, original)
        self._module = None
        self._originals = {}
        self.installed = False
        self.reason = "uninstalled"

    # -- the wrapper -----------------------------------------------------

    def _wrap(self, original: Callable) -> Callable:
        binding = self

        @functools.wraps(original)
        def _kame_dispatch(agent, api_kwargs, *args, **kwargs):
            if settings.is_on(settings.ROTATION_DISABLED) or settings.is_on(
                settings.CAROUSEL_DISABLED
            ):
                return original(agent, api_kwargs, *args, **kwargs)
            try:
                return binding.run(original, agent, api_kwargs, args, kwargs)
            except _CONTROL_FLOW:
                raise
            except Exception:
                raise

        setattr(_kame_dispatch, _MARK, True)
        return _kame_dispatch

    # -- the carousel ----------------------------------------------------

    def run(
        self,
        original: Callable,
        agent: Any,
        api_kwargs: Any,
        args: Sequence[Any],
        kwargs: Dict[str, Any],
    ) -> Any:
        """One API call, as many keys as it takes."""
        try:
            keys, entry_by_key = candidates(agent)
        except Exception:
            logger.debug("kame: could not read the agent's keys", exc_info=True)
            return original(agent, api_kwargs, *args, **kwargs)

        if not keys:
            # Nothing to choose from — an OAuth provider, a callable bearer, a
            # local model. The host's own call is the whole behaviour.
            return original(agent, api_kwargs, *args, **kwargs)

        identity = Carousel.identity(
            getattr(agent, "provider", ""), getattr(agent, "model", "")
        )
        label = identity
        started = time.monotonic()
        deadline = started + self.deadline_s
        self.calls += 1

        attempt = 0
        slept = False
        empty_budget = EMPTY_RETRY_BUDGET
        empty_counts: Dict[str, int] = {}
        last_error: Optional[BaseException] = None

        while True:
            attempt += 1
            if _interrupted(agent):
                if last_error is not None:
                    raise last_error
                return original(agent, api_kwargs, *args, **kwargs)

            key, status = self.engine.select(identity, keys)
            if key is None:
                return original(agent, api_kwargs, *args, **kwargs)

            if status == "EXHAUSTED":
                # Every key is resting. Calling one anyway would spend a
                # request we already know will be refused and would deepen the
                # cooldown that caused this. Wait for the soonest instead.
                if not self._wait_for_recovery(agent, identity, keys, label, deadline):
                    if last_error is not None:
                        self.surfaced += 1
                        raise last_error
                    # Nothing failed yet and the pool is cold from an earlier
                    # turn: let the host make the call and report honestly.
                    return original(agent, api_kwargs, *args, **kwargs)
                slept = True
                continue

            _apply_key(agent, key, entry_by_key.get(key))

            progress = _Progress()
            call_kwargs = dict(kwargs)
            restore = _install_shims(agent, progress, call_kwargs)
            try:
                result = original(agent, api_kwargs, *args, **call_kwargs)
            except _CONTROL_FLOW:
                raise
            except BaseException as exc:  # noqa: BLE001 — re-raised below unless rotatable
                last_error = exc
                verdict = self._on_failure(
                    identity, key, exc, label, attempt, progress.any
                )
                if verdict == "raise":
                    self.surfaced += 1
                    raise
                if time.monotonic() >= deadline:
                    logger.warning(
                        "kame: %s gave up after %s and %d attempt(s) — handing the "
                        "failure to Hermes",
                        label,
                        format_duration(time.monotonic() - started),
                        attempt,
                    )
                    self.surfaced += 1
                    raise
                self.rotations += 1
                continue
            finally:
                _remove_shims(agent, restore)

            # An answer that carried nothing. Usually a provider hiccup or a
            # filtered completion, so the first one from a key costs it
            # nothing. A second from the same key rests it briefly. Bounded by
            # the budget, after which the empty answer is returned exactly as
            # the host would have returned it — this can never become a loop.
            if empty_budget > 0 and not progress.any and _result_is_empty(result):
                empty_budget -= 1
                empty_counts[key] = empty_counts.get(key, 0) + 1
                if empty_counts[key] >= 2:
                    self.engine.mark(identity, key, False, EMPTY_REST_S, "other")
                logger.info(
                    "kame: %s %s answered with nothing (%d) — next key",
                    label,
                    fingerprint(key),
                    empty_counts[key],
                )
                self.rotations += 1
                continue

            self.engine.mark(identity, key, True)
            if slept:
                thawed = self.engine.thaw_server_cooled(identity, key)
                if thawed:
                    logger.info(
                        "kame: %s recovered — %d key(s) brought back early", label, thawed
                    )
            if attempt > 1:
                self.recovered += 1
                logger.info(
                    "kame: %s answered on attempt %d with %s after %s",
                    label,
                    attempt,
                    fingerprint(key),
                    format_duration(time.monotonic() - started),
                )
            return result

    # -- the two decisions -----------------------------------------------

    def _on_failure(
        self,
        identity: str,
        key: str,
        exc: BaseException,
        label: str,
        attempt: int,
        streamed: bool,
    ) -> str:
        """``"rotate"`` or ``"raise"``, and the key's rest recorded either way.

        A failure is always *learned from*, even when it is re-raised — a
        terminal error still tells us nothing bad about the key, and a
        mid-stream drop still does.
        """
        message = str(getattr(exc, "message", "") or "")
        if is_terminal(exc, message):
            logger.info(
                "kame: %s %s — the request itself was refused, not the key", label, type(exc).__name__
            )
            return "raise"

        delay, kind, status = classify(
            exc, message, daily_cooldown_s=self.engine.daily_cooldown_s
        )
        applied = self.engine.mark(identity, key, False, delay, kind, )
        # Never the error text: a provider's unredacted dump of a failed auth
        # call can carry the key that failed.
        logger.warning(
            "kame: %s %s %s%s — resting %s, taking the next key (attempt %d)",
            label,
            fingerprint(key),
            kind,
            f" [{status}]" if status else "",
            format_duration(applied),
            attempt,
        )
        if is_auth_failure(exc, message):
            # Actionable and permanent: this one is worth saying loudly, once
            # per occurrence, because no amount of rotation repairs it.
            logger.error(
                "kame: %s %s is not a valid credential — quarantined for %s. "
                "Replace it in Settings; the remaining keys are carrying this turn.",
                label,
                fingerprint(key),
                format_duration(applied),
            )
        if streamed:
            # The user has already seen part of an answer. Replaying it would
            # print the response twice, so this one goes back to Hermes, which
            # knows how to continue a cut-off response.
            logger.info(
                "kame: %s dropped mid-answer — handing it to Hermes rather than "
                "printing the reply twice",
                label,
            )
            return "raise"
        return "rotate"

    def _wait_for_recovery(
        self,
        agent: Any,
        identity: str,
        keys: Sequence[str],
        label: str,
        deadline: float,
    ) -> bool:
        """Sleep until the soonest key is usable. ``False`` means out of time.

        Slept in one-second slices so an interrupt is honoured promptly, and
        capped so a long cooldown is re-checked rather than committed to: a key
        that recovers early, or a pool that gains a key, is used immediately.
        """
        eta = self.engine.next_recovery_seconds(identity, keys)
        if eta is None:
            return True
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            return False
        wait = min(eta + 0.5, _MAX_SLEEP_S, remaining)
        if wait <= 0:
            return False
        logger.warning(
            "kame: %s every key is resting — waiting %s (no requests sent); "
            "earliest recovery in %s",
            label,
            format_duration(wait),
            format_duration(eta),
        )
        slept = 0.0
        while slept < wait:
            if _interrupted(agent):
                return False
            slice_s = min(_SLEEP_SLICE_S, wait - slept)
            time.sleep(slice_s)
            slept += slice_s
        return time.monotonic() < deadline


def install(module: Optional[Any] = None) -> Optional[DispatchBinding]:
    """Convenience entry point used by ``register()``; never raises.

    Imports the module when it is not already loaded, for the same reason the
    resolver binding does: plugin registration runs early, and a binding that
    installs only when something happened to import the host module first is a
    binding that works on some starts and not others. The module is plain — no
    server, no socket, no I/O at import.
    """
    if settings.is_on(settings.ROTATION_DISABLED) or settings.is_on(
        settings.CAROUSEL_DISABLED
    ):
        return None
    try:
        if module is None:
            module = sys.modules.get(_MODULE)
        if module is None:
            from importlib import import_module

            module = import_module(_MODULE)
        binding = DispatchBinding(deadline_s=settings.number(settings.CAROUSEL_DEADLINE, DEFAULT_DEADLINE_S))
        binding.engine.daily_cooldown_s = settings.number(
            settings.DAILY_COOLDOWN, binding.engine.daily_cooldown_s
        )
        return binding if binding.install(module) else None
    except ImportError:
        logger.debug("kame: no %s to bind", _MODULE)
        return None
    except Exception:
        logger.warning("kame: every call keeps the host's key", exc_info=True)
        return None

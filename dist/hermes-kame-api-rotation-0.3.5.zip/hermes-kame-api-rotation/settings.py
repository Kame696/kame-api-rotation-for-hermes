"""The two switches, read from where Hermes keeps switches.

Both of this plugin's knobs were environment variables and nothing else,
which made them correct and invisible. Hermes has a place for exactly this:
a manifest declares ``config_schema``, the user writes
``plugins.entries.<id>.settings.<key>`` in ``config.yaml``, and the plugin
reads it back through ``ctx.get_config`` (``hermes_cli/plugins.py:1422``).
A knob that does not appear there is a knob nobody finds.

**The environment still wins.** ``KAME_ROTATION_DISABLED`` is the escape
hatch — the thing somebody reaches for when they suspect this plugin of
breaking their agent, from a shell, without editing a YAML file they may
never have created. A config file that could override it would make the
emergency switch conditional on the state it exists to rule out. So the
order is: environment if it says anything at all, config otherwise, and the
built-in default when neither speaks.

**Read once, at registration.** ``ctx.get_config`` calls
``load_config_readonly()`` on every access, and these are consulted on the
classification path and on the selection path — every failed call and every
credential handed out. A config file is re-read when Hermes restarts, which
is what changing a config file already means everywhere else in the host.

Nothing here can prevent the plugin from loading. A context without
``get_config``, a config that will not parse, a value of an unexpected type:
each falls back to the environment, which falls back to the default. The
failure mode of a switch must never be worse than the feature it switches.
"""

from __future__ import annotations

import logging
import os
from typing import Dict, Optional

logger = logging.getLogger(__name__)

# What counts as "on" when the value arrives as text — from the environment
# always, and from YAML when somebody quoted it. Booleans arrive as booleans.
_TRUE = frozenset({"1", "true", "yes", "on"})
_FALSE = frozenset({"0", "false", "no", "off"})

# key in config.yaml -> environment variable that outranks it
ROTATION_DISABLED = "disabled"
SPREAD_DISABLED = "spread_disabled"

_ENV_FOR = {
    ROTATION_DISABLED: "KAME_ROTATION_DISABLED",
    SPREAD_DISABLED: "KAME_SPREAD_DISABLED",
}

# What the config file said, filled in once at registration. Empty until then,
# and empty forever on a host that offers no config surface — which is the
# same behaviour every version before this one had.
_FROM_CONFIG: Dict[str, bool] = {}


def _as_flag(value: object) -> Optional[bool]:
    """A truthy/falsy reading of one setting, or ``None`` for "said nothing".

    ``None`` matters as much as the two answers. An unset variable and a
    value nobody can interpret both mean the next source down should decide,
    and a setting that silently reads as ``False`` would make a typo look
    exactly like a deliberate "off".
    """
    if value is None:
        return None
    if isinstance(value, bool):
        return value
    text = str(value).strip().lower()
    if text in _TRUE:
        return True
    if text in _FALSE:
        return False
    return None


def load(ctx) -> None:
    """Read both switches out of the host's config, once.

    Called from ``register``. Anything that goes wrong here leaves the
    plugin exactly as it was before config was a source at all.
    """
    _FROM_CONFIG.clear()
    getter = getattr(ctx, "get_config", None)
    if not callable(getter):
        return
    for key in _ENV_FOR:
        try:
            raw = getter(key, None)
        except Exception:
            # Includes the host rejecting the key outright, which it does by
            # raising. One unusable setting must not cost the other one.
            logger.debug("%s: could not read the %r setting", __name__, key, exc_info=True)
            continue
        flag = _as_flag(raw)
        if flag is None:
            if raw is not None:
                # Worth a line: the user wrote something and got the default.
                # Silently ignoring it is how a switch is reported broken.
                logger.warning(
                    "kame: ignoring plugins.entries.hermes-kame-api-rotation"
                    ".settings.%s — expected true or false",
                    key,
                )
            continue
        _FROM_CONFIG[key] = flag


def forget() -> None:
    """Drop what was read. For tests and for a re-registration."""
    _FROM_CONFIG.clear()


def is_on(key: str) -> bool:
    """Whether the named switch is set, environment first.

    Defaults to ``False`` for both, which is the plugin doing its whole job:
    a switch that is not mentioned anywhere leaves every feature running.
    """
    from_env = _as_flag(os.environ.get(_ENV_FOR.get(key, ""), None))
    if from_env is not None:
        return from_env
    return bool(_FROM_CONFIG.get(key, False))
